#if ( __GNUC_MINOR__ < 7 )
#pragma interface
#endif

/***************************************************************/
/*                                                             */
/*  this header-file was modified by Robert Hoehne             */
/*  to use it with DJ's port of gcc                            */
/*                                                             */
/***************************************************************/


#if defined( Uses_TVEdConstant ) && !defined( __TVEdConstant )
#define __TVEdConstant

const ushort
  cmOpen       = 100,
  cmNew        = 101,
  cmChangeDrct = 102,
  cmDosShell   = 103,
  cmCalculator = 104,
  cmShowClip   = 105,
  cmMacros     = 106;

typedef struct {
  ushort code;
  char * Name;
} Const_Rec;

extern Const_Rec StdConstants[];
extern Const_Rec *UserConstants;
extern int UserConstantsCount;

#endif
