#if ( __GNUC_MINOR__ < 7 )
#pragma interface
#endif

/***************************************************************/
/*                                                             */
/*  this header-file was modified by Robert Hoehne             */
/*  to use it with DJ's port of gcc                            */
/*                                                             */
/***************************************************************/


/* ------------------------------------------------------------------------*/
/*                                                                         */
/*   TTYPES.H                                                              */
/*                                                                         */
/*   Copyright (c) Borland International 1991                              */
/*   All Rights Reserved.                                                  */
/*                                                                         */
/* ------------------------------------------------------------------------*/

#if !defined( __TTYPES_H )
#define __TTYPES_H

enum Boolean { False, True };

typedef short int16;
typedef int int32;
typedef unsigned short uint16;
typedef unsigned int uint32;

typedef unsigned short ushort;
typedef unsigned char uchar;

const char EOS = '\0';

enum StreamableInit { streamableInit };

class far ipstream;
class far opstream;
class far TStreamable;
class far TStreamableTypes;

typedef int32 ccIndex;
typedef Boolean (*ccTestFunc)( void *, void * );
typedef void (*ccAppFunc)( void *, void * );

const ccNotFound = -1;

extern const uchar specialChars[];


#endif	// __TTYPES_H
