/*  
//   djp.c -- DJGPP V2 executable file compressor with the LZO1 algorithm
//
//   Copyright (C) 1996 Molnar Laszlo, see COPYING.DJ for details
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stubinfo.h>
#include <process.h>

#include "lzo1.h"
#define SIMAGIC "go32stub"

static FILE *fi,*fo;             /* input,output */

static char wrkmem[LZO1_99_MEM_COMPRESS];  /* for lzo1_99 compression*/
static unsigned char stub[]={
#include "djp.h"
};
static char *packerr;
static char tmp_file[200];

#define BACK29 "\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b"

static int pack_sections (char *in,char *out,unsigned foffset,unsigned size)
{
    unsigned packedsize,new_size;
    unsigned adler1,adler2;

    packerr=NULL;
    if (in==NULL || out==NULL)
    {
        packerr="out of memory";
        return -1;
    }
    fseek (fi,foffset,0);

    if (fread (in,size,1,fi)!=1)
    {
        packerr="read error";
        return -1;
    }
    packedsize=0;

    /* compute checksum of uncompressed data */
    adler1 = lzo_adler32 (0,NULL,0);
    adler1 = lzo_adler32 (adler1,in,size);

    /* put your compressor here - and your decompressor into djpstub.asm */
    if (lzo1_99_compress (in,size,out,&packedsize,wrkmem) || size <= packedsize)
    {
        packerr="compression failed";
        return -1;
    }

    printf ("%8d -> %8d ratio:%d%%",size,packedsize,(packedsize*100)/size);
    /* decompress and verify */
    if (lzo1_decompress (out,packedsize,in,&new_size,wrkmem) != 0)
    {
        packerr="decompression failed";
        return -1;
    }
    if (new_size != size)
    {
        packerr="decompression size error";
        return -1;
    }
    /* compute checksum of decompressed data */
    adler2 = lzo_adler32(0, NULL, 0);
    adler2 = lzo_adler32(adler2, in, new_size);
    if (adler1 != adler2)
    {
        packerr="decompression data error";
        return -1;
    }
    if (fwrite (out,packedsize,1,fo)!=1)
    {
        packerr="write error";
        return -1;
    }
    return packedsize;
}

static const char *v2packimage(const char *program)
{
    unsigned short header[0x1c/2];
    char     magic[8],*p1,*in,*out;

    unsigned coff_offset=0,size;
    unsigned long coffhdr[42];
    unsigned text_size,data_size;
    int      wasexe=0;

    printf ("%-32.32s",program);
    fflush (stdout);
    if ((fi = fopen (program,"rb"))==NULL)
        return "can't open";
    if (fread (header,sizeof(header),1,fi)!=1)
        return "read error";
    if (header[0] == 0x5a4d)                    /* MZ exe signature, stubbed? */
    {
        if (header[0x1a/2] != 0x7473)           /* 'st' */
            return "not DJ's original stub";
        coff_offset = (long)header[2]*512L;
        if (header[1])
            coff_offset += (long)header[1] - 512L;
        fseek (fi, 512, 0);                     /* Position of V2 stubinfo */
        if (fread (magic,8,1,fi)!=1)
            return "read error";
        if (memcmp (SIMAGIC,magic,8) != 0)
            return "bad MAGIC";                 /* Not V2 image, show failure */
        wasexe=1;
    }
    /* Check for real image, (for now assume imbedded) */
    fseek (fi,coff_offset,0);
    if (fread (coffhdr,0x0a8,1,fi)!=1)
        return "can't read COFF header";
    if (*(short*)&coffhdr[0] != 0x014c)         /* COFF? */
        return "not V2 image";                  /* Not V2 image, show failure */
    if ((coffhdr[4] & 0x00020000)==0)
        return "COFF not executable";           /* Not executable */
    if (coffhdr[12+3]+coffhdr[12+4] != coffhdr[22+3] ||
        coffhdr[22+3]+coffhdr[22+4] != coffhdr[32+3])
    {
        return "already packed";
    }

    strcpy (tmp_file,program);
    tmp_file[strlen(tmp_file)-1]=254;
    if ((fo=fopen (tmp_file,"wb"))==NULL)
        return "can't open temp file";
    if (fwrite (stub,sizeof(stub),1,fo)!=1)
        return "write error";
    text_size = coffhdr[12 + 4];                /* size */
    data_size = coffhdr[22 + 4];

    if (fwrite (coffhdr,sizeof(coffhdr),1,fo)!=1)
        return "write error";

    /* "strip" debug info */
    coffhdr[12+6]=coffhdr[12+7]=coffhdr[12+8]=coffhdr[2]=coffhdr[3]=0;
    coffhdr[4]=(coffhdr[4]&0xFFFF)|(0x010F0000);

    size=((text_size+511)&~511)+data_size;
    in=(char*)malloc (size+512);
    out=(char*)malloc (size+512);
    coffhdr[12+4]=pack_sections(in,out,coff_offset,size);

    if (in!=NULL)
        free (in);
    if (out!=NULL)
        free (out);
    if (packerr != NULL)
        return packerr;

    coffhdr[22+5]=coffhdr[22+4]=0;

    fseek (fo,sizeof(stub),0);
    fwrite (coffhdr,sizeof(coffhdr),1,fo);
    fclose (fi);
    fclose (fo);
    fi=fo=NULL;

    strcpy (wrkmem,program);

    if ((p1=strrchr (wrkmem,'.'))!=NULL)
        wrkmem[strlen(wrkmem)-1]='~';           /* backup file name */
    else
        strcat (wrkmem,".~");

    /* if rename() were here, the compressor would be 10 kbyte bigger */
    if (_rename (program,wrkmem)!=0)
        return BACK29 "can't rename .exe file";
    else
    {
        strcpy (wrkmem,program);
        if (!wasexe)
            strcat (wrkmem,".exe");
        if (_rename (tmp_file,wrkmem)!=0)
            return BACK29 "can't rename .~ file";
    }
    tmp_file[0]=0;
    return NULL;
}

static int unpack_section (char *in,char *out,unsigned foffset,unsigned isize)
{
    unsigned unpackedsize;

    packerr=NULL;
    if (in==NULL || out==NULL)
    {
        packerr="out of memory";
        return -1;
    }
    fseek (fi,foffset,0);

    if (fread (in,isize,1,fi)!=1)
    {
        packerr="read error";
        return -1;
    }
    /* put your compressor here - and your decompressor into djpstub.asm */
    if (lzo1_decompress (in,isize,out,&unpackedsize,NULL))
    {
        packerr="decompression failed";
        return -1;
    }

    printf ("%8d -> %8d%10.10s",isize,unpackedsize,"");

    if (fwrite (out,unpackedsize,1,fo)!=1)
    {
        packerr="write error";
        return -1;
    }
    return unpackedsize;
}

static const char *v2unpackimage (const char *program)
{
    unsigned short header[0x1c/2];
    char     magic[8],*p1,*in,*out;

    unsigned coff_offset=0,size;
    unsigned long coffhdr[42];
    unsigned text_size,data_size;

    printf ("%-32.32s",program);
    fflush (stdout);
    if ((fi = fopen (program,"rb"))==NULL)
        return "can't open";
    if (fread (header,sizeof(header),1,fi)!=1)
        return "read error";
    if (header[0] == 0x5a4d)                    /* MZ exe signature, stubbed? */
    {
        if (header[0x1a/2] != 0x6a64)           /* 'dj' */
            return "not compressed with DJP";
        coff_offset = (long)header[2]*512L;
        if (header[1])
            coff_offset += (long)header[1] - 512L;
        fseek (fi, 512, 0);                     /* Position of V2 stubinfo */
        if (fread (magic,8,1,fi)!=1)
            return "read error";
        if (memcmp (SIMAGIC,magic,8) != 0)
            return "bad MAGIC";                 /* Not V2 image, show failure */
    }
    else
        return "not EXE";

    fseek (fi,coff_offset,0);
    if (fread (coffhdr,0x0a8,1,fi)!=1)
        return "can't read coff header";
    if (*(short*)&coffhdr[0] != 0x014c)         /* COFF? */
        return "not V2 image";                  /* Not V2 image, show failure */

    strcpy (tmp_file,program);
    tmp_file[strlen(tmp_file)-1]=254;
    if ((fo=fopen (tmp_file,"wb"))==NULL)
        return "can't open temp file";

    text_size = coffhdr[12 + 4];                /* size */
    data_size = coffhdr[22 + 4];

    size=text_size > data_size ? text_size : data_size;
    in=(char*)malloc (size+512);
    out=(char*)malloc (coffhdr[6]+coffhdr[7]+512);

    if (unpack_section (in,out,coff_offset+0xa8,text_size)==-1 ||
        (data_size && unpack_section (in,out,coff_offset+0xa8+text_size,data_size)==-1))
    {}
    if (in!=NULL)
        free (in);
    if (out!=NULL)
        free (out);
    if (packerr!=NULL)
        return packerr;

    /* restore original size and file offset */
    coffhdr[12+4]=coffhdr[6];
    coffhdr[22+4]=coffhdr[7];
    coffhdr[22+5]=coffhdr[22+3]-0x1000;
    fseek (fo,0,0);
    fwrite (coffhdr,sizeof(coffhdr),1,fo);
    fclose (fi);
    fclose (fo);
    fi=fo=NULL;

    strcpy (wrkmem,program);

    if ((p1=strrchr (wrkmem,'.'))!=NULL)
        wrkmem[strlen(wrkmem)-1]='~';           /* backup file name */
    else
        strcat (wrkmem,".~");

    /* if rename() were here, the decompressor would be 10 kbyte bigger */
    if (_rename (program,wrkmem)!=0)
        return BACK29 "can't rename .exe file";
    else
    {
        if (spawnlp (P_WAIT,"stubify.exe","stubify.exe",tmp_file,NULL))
            return BACK29 "stubify error";
    }
    return NULL;
}

/* Don't link this function from libc.a ==> -1600 bytes */
int _is_executable (const char *p,int i,const char *q)
{
    return 0;
}

int main(int argc, char **argv)
{
    int isunpack,waserror=0,ic;
    const char *p;

    printf ("\nDJP 1.03 executable file compressor for DJGPP V2 programs."
            " (C) 1996 ML1050\n"
            "LZO data compression (C) 1996 Markus Franz Xaver Johannes Oberhumer\n\n");
    if (argc < 2)
    {
        printf ("Usage: %s [-d[ecompress]] exefile [exefiles]\n",argv[0]);
        return 1;
    }

    isunpack=strnicmp ("-d",argv[1],2)==0;
    for (ic=1+isunpack; ic<argc; ic++)
    {
        fi=fo=NULL;
        tmp_file[0]=0;
        if (!isunpack)
        {
            if ((p=v2packimage(argv[ic]))!=NULL)
            {
                printf ("%s!\t\t",p);
                waserror++;
            }
            printf ("\n");
        }
        else
        {
            if ((p=v2unpackimage(argv[ic]))!=NULL)
            {
                printf ("%s!",p);
                waserror++;
            }
            printf ("\n");
        }
        if (fi!=NULL)
            fclose (fi);
        if (fo!=NULL)
            fclose (fo);
        if (tmp_file[0])
            remove (tmp_file);
    }
    return waserror;
}
