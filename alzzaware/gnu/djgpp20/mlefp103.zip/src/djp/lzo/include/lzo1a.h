/* dummy file for DJP distribution */
