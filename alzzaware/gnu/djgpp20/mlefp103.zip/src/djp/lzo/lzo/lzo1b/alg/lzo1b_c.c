/* lzo1b_c.c -- implementation of the LZO1B compression algorithm

   This file is part of the LZO real-time data compression library.

   Copyright (C) 1996 Markus Franz Xaver Johannes Oberhumer

   The LZO library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Library General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.

   The LZO library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with the LZO library; see the file COPYING.LIB.
   If not, write to the Free Software Foundation, Inc.,
   675 Mass Ave, Cambridge, MA 02139, USA.

   Markus F.X.J. Oberhumer
   markus.oberhumer@jk.uni-linz.ac.at
 */



/***********************************************************************
//
************************************************************************/

#if !defined(MAX_OFFSET)
#  define MAX_OFFSET	M4_MAX_OFFSET
#endif


#if !defined(LZO_HAVE_R1) && !defined(LZO_NO_R1)
#  define LZO_HAVE_R1
#endif

#if !defined(LZO_HAVE_M3) && !defined(LZO_NO_M3)
#  if (M3O_BITS < 8)
#    define LZO_HAVE_M3
#  endif
#endif


#define MI
#define SI		MI
#define DI		++ii; DVAL_NEXT(dv,ii); UPDATE_D(dict,cycle,dv,ii); MI
#define XI		assert(ii < ip); ii = ip; DVAL_FIRST(dv,(ip));


#if 0 && defined(LZO_DETERMINISTIC)
   /* this line causes problems on some architectures */
#  define CHECK_MPOS(m_pos,m_off,in,ip,max_offset) \
	(BOUNDS_CHECKING_OFF_IN_EXPR( \
		(m_off = ip - m_pos) > max_offset ))

#elif defined(LZO_DETERMINISTIC)
   /* this is the safe (but slower) version */
#  define CHECK_MPOS(m_pos,m_off,in,ip,max_offset) \
		(m_pos == NULL || (m_off = ip - m_pos) > max_offset)

#else
   /* m_pos may point anywhere ... */
#  define CHECK_MPOS(m_pos,m_off,in,ip,max_offset) \
	(BOUNDS_CHECKING_OFF_IN_EXPR( \
		(m_pos < in || (m_off = ip - m_pos) <= 0 || m_off > max_offset) ))
#endif



/***********************************************************************
// compress a block of data.
// return 0 for success
//
// I really apologize for the spaghetti code, but I wanted to keep
// everything in one source file and I've done my best to
// help the optimizer.
************************************************************************/

static int
do_compress    ( const lzo_byte *in , lzo_uint  in_len,
                       lzo_byte *out, lzo_uint *out_len,
                       lzo_voidp wrkmem )
{
/* this seems to work with buggy gcc */
/* #if defined(LZO_OPTIMIZE_GNUC_i386) */
#if defined(__GNUC__) && defined(__i386__)
	register const lzo_byte *ip __asm__("%esi");
#else
	register const lzo_byte *ip;
#endif
#if defined(LZO_HASH_INCREMENTAL)
	lzo_uint dv;
#endif
#if (DD_BITS > 0)
	unsigned cycle = 0;
#endif
	lzo_byte *op;
	const lzo_byte * const in_end = in + in_len - DVAL_LOOKAHEAD;
	const lzo_byte * const ip_end = in + in_len - MIN_LOOKAHEAD;
	const lzo_byte *ii;
#if defined(LZO_HAVE_R1)
	const lzo_byte *r1 = ip_end;	/* pointer for R1 match (none yet) */
#endif
#if defined(LZO_HAVE_M3)
	lzo_byte *m3 = out + 1;			/* pointer after last m3/m4 match */
#endif

	const lzo_bytepp const dict = wrkmem;

#if defined(LZO_COLLECT_STATS)
	lzo_stats->r_bits   = R_BITS;
	lzo_stats->m3o_bits = M3O_BITS;
	lzo_stats->dd_bits  = DD_BITS;
	lzo_stats->clevel   = CLEVEL;
	lzo_stats->d_bits   = D_BITS;
	lzo_stats->min_lookahead  = MIN_LOOKAHEAD;
	lzo_stats->max_lookbehind = MAX_LOOKBEHIND;
	lzo_stats->compress_id    = _LZO_MEXPAND(COMPRESS_ID);
#endif

	/* init dictionary */
#if defined(LZO_DETERMINISTIC)
	BZERO8_PTR(dict,D_SIZE);
	assert(dict[0] == NULL);				/* assert NULL == 0 */
#endif


	op = out;
	ip = in;
	ii = ip;			/* point to start of current literal run */


	DVAL_FIRST(dv,ip);
	UPDATE_D(dict,cycle,dv,ip);

	ip++;
	DVAL_NEXT(dv,ip);


	while (ip < ip_end)
	{
		const lzo_byte *m_pos;
#if !defined(NDEBUG)
		const lzo_byte *m_pos_sav = NULL;
#endif
		lzo_uint m_len;
		lzo_ptrdiff_t m_off;

/***********************************************************************
// step 1: search for a match
************************************************************************/

#if (DD_BITS == 0)

		/* search ip in the dictionary */
		{
			lzo_uint dindex;

			dindex = DINDEX(dv,ip);
			m_pos = dict[dindex];
			dict[dindex] = ip;

#if !defined(NDEBUG)
			DVAL_ASSERT(dv,ip);
#if defined(LZO_DETERMINISTIC)
			assert(m_pos == NULL || m_pos >= in);
			assert(m_pos == NULL || m_pos < ip);
#endif
			m_pos_sav = m_pos;
#endif
		}

	/* check potential match in m_pos:
	 * range must fit, first 3 (M2_MIN_LEN) bytes must match */

		if (CHECK_MPOS(m_pos,m_off,in,ip,MAX_OFFSET) ||
		    (*m_pos++ != ip[0] || *m_pos++ != ip[1]))
		{
			/* could experiment with a M1 match here */
		}
		else
		{
			if (*m_pos++ == ip[2])
			{
				if (m_off <= M2_MAX_OFFSET)
					goto match;
				if (*m_pos == ip[3])
					goto match;
#if 0 && (M3_MIN_LEN == M2_MIN_LEN)
				if (ip == ii)
					goto match;
#endif
			}
		}


#else /* (DD_BITS == 0) */


		/* search ip in the deepened dictionary */
		{
			const lzo_bytepp d = &dict [ DINDEX(dv,ip) ];
			const lzo_byte *ip_sav;
			unsigned j = DD_SIZE;
			lzo_uint x_len;
			lzo_ptrdiff_t x_off;

			DVAL_ASSERT(dv,ip);

			ip_sav = ip;
			m_len = 0;
			do {
				assert(ip == ip_sav);
				m_pos = *d;
#if defined(LZO_DETERMINISTIC)
				assert(m_pos == NULL || m_pos >= in);
				assert(m_pos == NULL || m_pos < ip);
#endif

				if (CHECK_MPOS(m_pos,x_off,in,ip,MAX_OFFSET))
#if (CLEVEL == 9)
					*d = ip;
#else
					((void)(0));
#endif
				else if (m_pos[m_len] != ip[m_len])
					((void)(0));
				else if (*m_pos++ == *ip++ && *m_pos++ == *ip++ && *m_pos++ == *ip++)
				{
					/* a match */
					if (MATCH_M2)
					{
						x_len = (ip - 1) - ip_sav;
						if (x_len > m_len)
						{
							m_len = x_len;
							m_off = x_off;
							assert((m_pos_sav = *d) != NULL);
						}
#if (CLEVEL == 9)
						/* try to find a closer match */
						else if (x_len == m_len && x_off < m_off)
						{
							m_off = x_off;
							assert((m_pos_sav = *d) != NULL);
						}
#endif
					}
					else
					{
						assert((ip - ip_sav) == M2_MAX_LEN + 1);
#if (CLEVEL == 9)
						/* try to find a closer match */
						if (m_len < M2_MAX_LEN + 1 || x_off < m_off)
						{
							m_len = M2_MAX_LEN + 1;
							m_off = x_off;
							assert((m_pos_sav = *d) != NULL);
						}
#else
						/* don't search for a longer/closer match */
						m_len = M2_MAX_LEN + 1;
						m_off = x_off;
						assert((m_pos_sav = *d) != NULL);
						ip = ip_sav;
						d -= DD_SIZE - j;
						assert(d == &dict [ DINDEX(dv,ip) ]);
						UPDATE_P(d,cycle,ip);
						goto match;
#endif
					}
					ip = ip_sav;
				}
				else
					ip = ip_sav;
				d++;
			} while (--j > 0);
			assert(ip == ip_sav);

			d -= DD_SIZE;
			assert(d == &dict [ DINDEX(dv,ip) ]);
			UPDATE_P(d,cycle,ip);
		}

	/* check potential match */

		if (m_len > M2_MIN_LEN)
			goto match;
		if (m_len == M2_MIN_LEN)
		{
			if (m_off <= M2_MAX_OFFSET)
				goto match;
#if 0 && (M3_MIN_LEN == M2_MIN_LEN)
			if (ip == ii)
				goto match;
#endif
		}


#endif /* (DD_BITS == 0) */



/***********************************************************************
// found a literal
************************************************************************/


	/* a literal */

		++ip;
		DVAL_NEXT(dv,ip);

		continue;



/***********************************************************************
// found a match
************************************************************************/

match:

	/* we have found a match of at least M2_MIN_LEN */

	/* 1) store the current literal run */

		assert(ip < ip_end);
		if (ip - ii > 0)
		{
			lzo_uint t = ip - ii;

#if defined(LZO_HAVE_R1)
			if (ip == r1)
			{
				/* Code a context sensitive R1 match. */
				LZO_STATS(lzo_stats->literals += t);
				LZO_STATS(lzo_stats->r1_matches++);
				assert(t == 1);
				/* modify marker byte */
				assert((op[-2] >> M2O_BITS) == (M2_MARKER >> M2O_BITS));
				op[-2] &= M2O_MASK;
				assert((op[-2] >> M2O_BITS) == 0);
				/* copy 1 literal */
				*op++ = *ii++;
				r1 = ip + (M2_MIN_LEN + 1);		/* set new R1 pointer */
			}
			else 
#endif
			if (t < R0MIN)
			{
				/* inline the copying of a short run */
				LZO_STATS(lzo_stats->literals += t);
				LZO_STATS(lzo_stats->lit_runs++);
				LZO_STATS(lzo_stats->lit_run[t]++);
#if defined(LZO_HAVE_M3)
				if (t < _SIZE(8-M3O_BITS) && op == m3)
				{
				/* Code a very short literal run into the low offset bits
				 * of the previous M3/M4 match.
				 */
					LZO_STATS(lzo_stats->lit_runs_after_m3_match++);
					LZO_STATS(lzo_stats->lit_run_after_m3_match[t]++);
					assert((m3[-2] >> M3O_BITS) == 0);
					m3[-2] |= LZO_BYTE(t << M3O_BITS);
				}
				else
#endif
				{
					*op++ = LZO_BYTE(t);
				}
				MEMCPY_DS(op, ii, t);
#if defined(LZO_HAVE_R1)
				r1 = ip + (M2_MIN_LEN + 1);		/* set new R1 pointer */
#endif
			}
			else if (t < R0FAST)
			{
				/* inline the copying of a short R0 run */
				LZO_STATS(lzo_stats->literals += t);
				LZO_STATS(lzo_stats->r0short_runs++);
				*op++ = 0; *op++ = LZO_BYTE(t - R0MIN);
				MEMCPY_DS(op, ii, t);
#if defined(LZO_HAVE_R1)
				r1 = ip + (M2_MIN_LEN + 1);		/* set new R1 pointer */
#endif
			}
			else
			{
				op = STORE_RUN(op,ii,t);
				ii = ip;
			}
		}


		/* ii now points to the start of the current match */
		assert(ii == ip);


/***********************************************************************
// code the match
************************************************************************/

#if !defined(LZO_CODE_MATCH_INCLUDE_FILE)
#  define LZO_CODE_MATCH_INCLUDE_FILE	"lzo1b/alg/lzo1b_cm.h"
#endif

#include LZO_CODE_MATCH_INCLUDE_FILE


		/* ii now points to the start of the next literal run */
		assert(ii == ip);

	}


/***********************************************************************
// end of block
************************************************************************/

	assert(ip <= in_end);

#if defined(LZO_RETURN_IF_NOT_COMPRESSIBLE)
	/* return if op == out to indicate that we
	 * couldn't compress and didn't copy anything.
	 */
	if (op == out)
	{
		*out_len = 0;
		return LZO_E_NOT_COMPRESSIBLE;
	}
#endif

	/* store the final literal run */
	if (in_end + DVAL_LOOKAHEAD - ii > 0)
	{
		lzo_uint t = in_end + DVAL_LOOKAHEAD - ii;
		op = STORE_RUN(op,ii,t);
	}

	*out_len = op - out;
	return LZO_E_OK;				/* compression went ok */
}


/*
vi:ts=4
*/
