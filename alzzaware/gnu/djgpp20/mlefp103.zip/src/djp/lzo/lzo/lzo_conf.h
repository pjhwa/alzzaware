/* lzo_conf.h -- main internal configuration file for the the LZO library

   This file is part of the LZO real-time data compression library.

   Copyright (C) 1996 Markus Franz Xaver Johannes Oberhumer

   The LZO library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Library General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.

   The LZO library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with the LZO library; see the file COPYING.LIB.
   If not, write to the Free Software Foundation, Inc.,
   675 Mass Ave, Cambridge, MA 02139, USA.

   Markus F.X.J. Oberhumer
   markus.oberhumer@jk.uni-linz.ac.at
 */


/* WARNING: this file should *not* be used by applications. It is
   part of the implementation of the library and is subject
   to change.
 */


#ifndef __LZO_CONF_H
#define __LZO_CONF_H


/***********************************************************************
//
************************************************************************/

#include <stddef.h>			/* ptrdiff_t */
#include <string.h>			/* memcpy, memmove, memcmp */

#if defined(__BOUNDS_CHECKING_ON)
#  include <unchecked.h>
#else
#  define BOUNDS_CHECKING_OFF_IN_EXPR(expr)		(expr)
#endif

#include <lzoconf.h>

/* ptrdiff_t */
#if (UINT_MAX >= 0xffffffffL)
   typedef ptrdiff_t        lzo_ptrdiff_t;
#else
   typedef long             lzo_ptrdiff_t;
#endif

/* Unsigned type that can store all bits of a lzo_voidp */
typedef unsigned long	lzo_ptr_t;

#define lzo_bytepp      lzo_byte * __LZO_MMODEL * 


/***********************************************************************
//
************************************************************************/

/* Generate compressed data in a deterministic way.
 * This is fully portable, and compression is faster as well.
 * The only reason NOT to be deterministic is when the block
 * size is very small (e.g. 8kB), because then the 
 * initialization of the dictionary becomes a relevant 
 * magnitude for compression speed.
 */
#define LZO_DETERMINISTIC


/***********************************************************************
// optimization
************************************************************************/

#if !defined(assert)
#  error <assert.h> not included
#endif


/* gcc 2.6.3 and gcc 2.7.2 have a bug */
#define LZO_OPTIMIZE_GNUC_i386_IS_BUGGY

/* Help the optimizer with register allocation.
 * Don't activate this macro for a fair comparision with other algorithms.
 */
#if 1 && defined(NDEBUG) && !defined(__BOUNDS_CHECKING_ON)
#  if defined(__GNUC__) && defined(__i386__)
#    if !defined(LZO_OPTIMIZE_GNUC_i386_IS_BUGGY)
#      define LZO_OPTIMIZE_GNUC_i386
#    endif
#  endif
#endif


/***********************************************************************
//
************************************************************************/

#define LZO_BYTE(x)		((unsigned char) (x))

#define lzo_sizeof(x)	((lzo_uint) (sizeof(x)))

#if !defined(HIGH)
#  define HIGH(x)		((lzo_uint) (sizeof(x)/sizeof(*(x))))
#endif

/* these always fit into 16 bits */
#define _SIZE(bits)		(1u << (bits))
#define _MASK(bits)		(_SIZE(bits) - 1)

/* these ... */
#define _LSIZE(bits)	(1ul << (bits))
#define _LMASK(bits)	(_LSIZE(bits) - 1)

/* these ... */
#define _USIZE(bits)	((lzo_uint) 1 << (bits))
#define _UMASK(bits)	(_USIZE(bits) - 1)


/***********************************************************************
// ANSI C preprocessor macros
************************************************************************/

#define _LZO_STRINGIZE(x)	#x
#define _LZO_MEXPAND(x)		_LZO_STRINGIZE(x)

/* concatenate */
#define _LZO_CONCAT2(a,b)			a ## b
#define _LZO_CONCAT3(a,b,c)			a ## b ## c
#define _LZO_CONCAT4(a,b,c,d)		a ## b ## c ## d
#define _LZO_CONCAT5(a,b,c,d,e)		a ## b ## c ## d ## e

/* expand and concatenate (by using one level of indirection) */
#define _LZO_ECONCAT2(a,b)			_LZO_CONCAT2(a,b)
#define _LZO_ECONCAT3(a,b,c)		_LZO_CONCAT3(a,b,c)
#define _LZO_ECONCAT4(a,b,c,d)		_LZO_CONCAT4(a,b,c,d)
#define _LZO_ECONCAT5(a,b,c,d,e)	_LZO_CONCAT5(a,b,c,d,e)



#endif /* already included */

/*
vi:ts=4
*/

