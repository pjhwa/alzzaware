
#define COMPRESS_ID		99

#define DDBITS			3
#define CLEVEL			9


/***********************************************************************
// 
************************************************************************/

#include "lzo1_99/config1.h"


/***********************************************************************
// compression internal entry point.
// return 0 for success, -1 for failure.
************************************************************************/

static
int _lzo1_do_compress    ( const lzo_byte *in,  lzo_uint  in_len,
								 lzo_byte *out, lzo_uint *out_len,
								 lzo_voidp wrkmem,
								 lzo_compress_t func )
{
	int r;

	/* sanity check */
	if (!lzo_assert(LZO1_99_MEM_COMPRESS >= D_SIZE * sizeof(lzo_byte *)))
		return LZO_E_ERROR;

	/* don't try to compress a block that's too short */
	if (in_len <= 0)
	{
		*out_len = 0;
		r = LZO_E_OK;
	}
	else if (in_len <= MIN_LOOKAHEAD + 1)
	{
#if defined(LZO_RETURN_IF_NOT_COMPRESSIBLE)
		*out_len = 0;
		r = LZO_E_NOT_COMPRESSIBLE;
#else
		*out_len = STORE_RUN(out,in,in_len) - out;
		r = (*out_len > in_len) ? LZO_E_OK : LZO_E_ERROR;
#endif
	}
	else
		r = func(in,in_len,out,out_len,wrkmem);

	return r;
}


/***********************************************************************
// 
************************************************************************/

#if !defined(COMPRESS_ID)
#define COMPRESS_ID		_LZO_ECONCAT2(DD_BITS,CLEVEL)
#endif


#define LZO_CODE_MATCH_INCLUDE_FILE		"lzo1_99/lzo1_cm.h"
#include "alg/lzo1b_c.c"


/***********************************************************************
// 
************************************************************************/

#define LZO_COMPRESS \
	_LZO_ECONCAT3(lzo1_,COMPRESS_ID,_compress)

#define LZO_COMPRESS_FUNC \
	_LZO_ECONCAT3(_lzo1_,COMPRESS_ID,_compress_func)


/***********************************************************************
// 
************************************************************************/

const lzo_compress_t LZO_COMPRESS_FUNC = do_compress;

int LZO_COMPRESS ( const lzo_byte *src, lzo_uint  src_len,
                         lzo_byte *dst, lzo_uint *dst_len,
                         lzo_voidp wrkmem )
{
	return _lzo1_do_compress(src,src_len,dst,dst_len,wrkmem,do_compress);
}

/*
vi:ts=4
*/
