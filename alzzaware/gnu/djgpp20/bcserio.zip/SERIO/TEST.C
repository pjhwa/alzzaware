#include <stdio.h>
#include <pc.h>
#include <keys.h>
#include "serio.h"

int main()
{
	int done=0,echo=0;
/*	sio_init(0x3f8,4);*/
	sio_init(0x2f8,3);
	sio_setparms(sio8Bits,sioNoParity,sio1StopBit);
/*	sio_setspeed(24);/*4800 baud*/
	sio_setspeed(48);/*2400 baud*/ /* this is the speed of my modem :)*/
	do {
		if (kbhit()) {
			int c=getkey();
			if (c>0x100) {
				switch (c) {
				case K_Alt_E:
					echo=!echo;
					break;
				case K_Alt_X:
					done=1;
					break;
				}
			} else {
				while (sio_put(c));
				if (echo) {
					putchar(c);
					if (c=='\r') putchar('\n');
					fflush(stdout);
				}
			}
		}
		if (sio_charready()) {
			int c=sio_get();
			putchar(c);
/*			if (c=='\r') putchar('\n');*/
			fflush(stdout);
		}
	} while (!done);
	sio_uninit();
	return 0;
}
