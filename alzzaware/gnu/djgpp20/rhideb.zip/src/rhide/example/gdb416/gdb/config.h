#ifndef _ALL_SOURCE
#undef _ALL_SOURCE
#endif

/* Define if the `long double' type works.  */
#define HAVE_LONG_DOUBLE 1

/* Define if you have a working `mmap' system call.  */
/* #undef HAVE_MMAP */

/* Define if on MINIX.  */
/* #undef _MINIX */

/* Define if the system does not provide POSIX.1 features except
   with this defined.  */
/* #undef _POSIX_1_SOURCE */

/* Define if you need to in order for stat and other things to work.  */
/* #undef _POSIX_SOURCE */

/* Define if the `S_IS*' macros in <sys/stat.h> do not work properly.  */
/* #undef STAT_MACROS_BROKEN */

/* Define if you have the ANSI C header files.  */
/* #undef STDC_HEADERS */

/* Define if fpregset_t type is available. */
/* #undef HAVE_FPREGSET_T */

/* Define if gregset_t type is available. */
/* #undef HAVE_GREGSET_T */

/* Define if the "%Lg" format works to print long doubles. */
/* #undef PRINTF_HAS_LONG_DOUBLE */

/* Define if you have the getpagesize function.  */
#define HAVE_GETPAGESIZE 1

/* Define if you have the sbrk function.  */
#define HAVE_SBRK 1

/* Define if you have the setpgid function.  */
/* #undef HAVE_SETPGID */

/* Define if you have the valloc function.  */
/* #undef HAVE_VALLOC */

/* Define if you have the <endian.h> header file.  */
/* #undef HAVE_ENDIAN_H */

/* Define if you have the <limits.h> header file.  */
#define HAVE_LIMITS_H 1

/* Define if you have the <link.h> header file.  */
/* #undef HAVE_LINK_H */

/* Define if you have the <memory.h> header file.  */
#define HAVE_MEMORY_H 1

/* Define if you have the <sgtty.h> header file.  */
/* #undef HAVE_SGTTY_H */

/* Define if you have the <stddef.h> header file.  */
#define HAVE_STDDEF_H 1

/* Define if you have the <string.h> header file.  */
#define HAVE_STRING_H 1

/* Define if you have the <strings.h> header file.  */
/* #undef HAVE_STRINGS_H */

/* Define if you have the <sys/procfs.h> header file.  */
/* #undef HAVE_SYS_PROCFS_H */

/* Define if you have the <termio.h> header file.  */
/* #undef HAVE_TERMIO_H */

/* Define if you have the <termios.h> header file.  */
#define HAVE_TERMIOS_H 1

/* Define if you have the <unistd.h> header file.  */
#define HAVE_UNISTD_H 1

/* Define if you have the dl library (-ldl).  */
/* #undef HAVE_LIBDL */

/* #define NO_MMALLOC */

