/* #define alloca __builtin_alloca */
#include <dirent.h>
typedef struct dirent dirent;

#define TERMIOS_MISSING
