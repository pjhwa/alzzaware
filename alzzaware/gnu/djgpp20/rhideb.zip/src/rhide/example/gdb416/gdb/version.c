char *version = "4.16";
char *host_name = "DJGPP(>=2.0)";
char *target_name = "DJGPP(>=2.0)";
