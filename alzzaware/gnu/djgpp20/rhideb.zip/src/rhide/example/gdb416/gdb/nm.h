#define NO_PTRACE_H

