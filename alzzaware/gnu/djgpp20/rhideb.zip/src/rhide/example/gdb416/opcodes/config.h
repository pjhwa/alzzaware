#define HAVE_STRING_H 1
