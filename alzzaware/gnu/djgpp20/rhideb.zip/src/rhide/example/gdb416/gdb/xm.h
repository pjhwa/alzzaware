#include <i386/xm-go32.h>
#include <limits.h>
