#define HAVE_STDDEF_H 1

#define HAVE_STRING_H 1

#define HAVE_STDLIB_H 1

#define HAVE_SYS_TIME_H 1

#define HAVE_UNISTD_H 1

#define USE_BINARY_FOPEN 1

#define HAVE_SYS_FILE_H 1

#undef NEED_DECLARATION_MALLOC

#undef NEED_DECLARATION_FREE

