// -*- C++ -*- backward compatiblity header.
// This file is part of the GNU ANSI C++ Library.

#ifndef __NEW_H__
#define __NEW_H__
#include <std/new.h>
#endif
