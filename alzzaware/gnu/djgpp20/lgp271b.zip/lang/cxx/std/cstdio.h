// The -*- C++ -*- standard I/O header.
// This file is part of the GNU ANSI C++ Library.

#ifndef __CSTDIO__
#define __CSTDIO__
#include <stdio.h>
#endif
