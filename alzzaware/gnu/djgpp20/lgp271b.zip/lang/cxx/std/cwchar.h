// The -*- C++ -*- wide character header.
// This file is part of the GNU ANSI C++ Library.

#ifndef __CWCHAR__
#define __CWCHAR__
#include <wchar.h>
#endif
