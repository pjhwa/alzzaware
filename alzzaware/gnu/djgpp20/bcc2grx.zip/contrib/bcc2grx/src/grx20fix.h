/* Map missing GRX20 routines to basic ones */

#if 1
#define GrCustomBox(x1,y1,x2,y2,opt) \
	      GrBox((x1),(y1),(x2),(y2),(opt)->lno_color)
#endif
#if 1
#define GrCustomLine(x1,y1,x2,y2,opt) \
	      GrLine((x1),(y1),(x2),(y2),(opt)->lno_color)
#endif
#if 1
#define GrPatternFilledBox(x1,y1,x2,y2,opt) \
	      GrFilledBox((x1),(y1),(x2),(y2),FILL)
#endif
#if 1
#define GrPatternFilledPolygon(num,pts,opt) \
	      GrFilledPolygon((num),(pts),FILL)
#endif
#if 1
#define GrPatternFilledLine(x1,y1,x2,y2,opt) \
	      GrLine((x1),(y1),(x2),(y2),FILL)
#endif
#if 1
#define GrPatternFilledEllipseArc(xc,yc,xa,ya,s,e,st,opt) \
	      GrFilledEllipseArc((xc),(yc),(xa),(ya),(s),(e),(st),FILL)
#endif

