#include <crt0.h>
int _crt0_startup_flags = _CRT0_FLAG_NO_LFN;
#include "lfn.c"
