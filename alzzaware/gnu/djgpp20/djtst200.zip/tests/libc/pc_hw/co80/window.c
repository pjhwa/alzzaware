#include <conio.h>

int
main(void)
{
  window(10, 3, 62, 10);
  gotoxy(10, 2);
  cputs("Hello, Conio!");
  return 0;
}
