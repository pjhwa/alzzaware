#include <sys/mono.h>

int
main(void)
{
  _mono_printf("Hello, there\r\n");
  return 0;
}
