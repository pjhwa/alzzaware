#include <crt0.h>
int _crt0_startup_flags = _CRT0_FLAG_NONMOVE_SBRK;
#include "near.c"
