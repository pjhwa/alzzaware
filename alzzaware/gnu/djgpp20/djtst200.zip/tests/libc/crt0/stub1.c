#include <stdio.h>

int
main(int argc, char **argv)
{
  printf("in stub1, argv[0] = `%s'\n", argv[0]);
  return 0;
}