#include <stdio.h>
#include <regex.h>

int
main(int argc, char **argv)
{
  rexec_
  regcomp("a.*x"
}
