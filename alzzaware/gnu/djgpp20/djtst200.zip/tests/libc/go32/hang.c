volatile int temp = 1;

int
main(void)
{
  while (temp);
  return 0;
}
