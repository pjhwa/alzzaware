#include <stdio.h>

int
main(void)
{
  printf("hello");
  printf(" there\n");
  return 0;
}
