/* -*-C-*- msqrt.c */

#include "elefunt.h"

int
main()
{
    init();
    tsqrt();
    return (EXIT_SUCCESS);
}
