/* -*-C-*- msin.c */

#include "elefunt.h"

int
main()
{
    init();
    tsin();
    return (EXIT_SUCCESS);
}
