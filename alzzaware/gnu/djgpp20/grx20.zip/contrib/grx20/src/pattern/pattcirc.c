/**
 ** CIRCLE.C
 **
 ** Copyright (c) 1995 Csaba Biegl, 820 Stirrup Dr, Nashville, TN 37221
 ** [e-mail: csaba@vuse.vanderbilt.edu] See "doc/copying.cb" for details.
 **
 **  Copyright (C) 1992, Csaba Biegl
 **    820 Stirrup Dr, Nashville, TN, 37221
 **    csaba@vuse.vanderbilt.edu
 **
 **  This file is distributed under the terms listed in the document
 **  "copying.cb", available from the author at the address above.
 **  A copy of "copying.cb" should accompany this file; if not, a copy
 **  should be available from where this file was obtained.  This file
 **  may not be distributed without a verbatim copy of "copying.cb".
 **  You should also have received a copy of the GNU General Public
 **  License along with this program (it is in the file "copying");
 **  if not, write to the Free Software Foundation, Inc., 675 Mass Ave,
 **  Cambridge, MA 02139, USA.
 **
 **  This program is distributed in the hope that it will be useful,
 **  but WITHOUT ANY WARRANTY; without even the implied warranty of
 **  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 **  GNU General Public License for more details.
 **/

#include "libgrx.h"
#include "shapes.h"

void GrPatternedEllipse(int xc,int yc,int xa,int ya,GrLinePattern *lp)
{
	int points[MAX_ELLIPSE_PTS+1][2];
	int numpts = _GrGenerateEllipse(points,xc,yc,xa,ya);
	GrCustomLineData args;

	_GrBuildCustomLineData(lp->lnp_option,&args);
	_GrSetupPatternedDraw(lp->lnp_pattern,&args);
	_GrDrawPolygon(numpts,points,
	    TRUE,
	    FALSE,
	    _GrDummyPatternedPixel,
	    _GrDoCustomSegment,
	    &args
	);
}

void GrPatternedEllipseArc(int xc,int yc,int xa,int ya,int start,int end,GrLinePattern *lp)
{
	int points[MAX_ELLIPSE_PTS+1][2];
	int numpts = _GrGenerateEllipseArc(points,xc,yc,xa,ya,start,end,FALSE);
	GrCustomLineData args;

	_GrBuildCustomLineData(lp->lnp_option,&args);
	_GrSetupPatternedDraw(lp->lnp_pattern,&args);
	_GrDrawPolygon(numpts,points,
	    FALSE,
	    FALSE,
	    _GrDummyPatternedPixel,
	    _GrDoCustomSegment,
	    &args
	);
}

void GrPatternedCircle(int xc,int yc,int r,GrLinePattern *lp)
{
	GrPatternedEllipse(xc,yc,r,r,lp);
}

void GrPatternedCircleArc(int xc,int yc,int r,int start,int end,GrLinePattern *lp)
{
	GrPatternedEllipseArc(xc,yc,r,r,start,end,lp);
}

