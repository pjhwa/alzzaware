#include <stdio.h>

int main(int argc, char *argv[])
{
  char *fname;

  while ((fname = *++argv))
  {
    if (fname[0] == '-')
      fprintf (stderr, "rm: option '%s' ignored\n", fname);
    else if (remove (fname))
      fprintf (stderr, "rm: unable to remove '%s'\n", fname);
  }
  return 0;
}
