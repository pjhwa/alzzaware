#include "thread.h"
#include "signal.h"
#include <stdlib.h>
#include <stdio.h>
#include "schedule.h"

void test(void * it)   /* functions to be threaded must be in this format
			  void function(void *) */
{
int x=0, i=0;
do{
for(x=0; x<=1; x++)
{
    printf("*4*\tx=%d\ti=%d\n", x, i);
}
    yield();
i++;
}while(i<=3);
    KillThread();    /* last thing in the function *** dont forget this *** */
}

void another(void * j)
{
int x=0, i=0;
do{
for(x=0; x<=1; x++)
{
    printf("*5*\tx=%d\ti=%d\n", x, i);
}
    yield();
i++;
}while(i<=3);
    KillThread();
}

int main(void)
{
char temp;
struct thread *one;   /* define three threads */
struct thread *two;
struct thread *eek;
CreateScheduler();    /* Create the scheduler */
CreateBlocker();      /* Create a list for blocked threads */
one = CreateThread(test, (void*)4);   /* Create a thread passing the function and a void pointer (for any data you may need) */
two = CreateThread(another, (void*)5);
block(one);   /* example of how to block a thread (going to be used for locks and semaphores, whenever I get around to it) */
block(two);
kick(two);    /* example of how to un-block a thread */
kick(one);
eek=0;       /* set eek to 0 */
MakeMain(eek);   /* make eek the main thread this is just so the first thread has something to switch from
		    don't worry this will soon change */
printf("one TID = %d\n", one->TID);   /* print out the thread ID's of the two created threads */
printf("two TID = %d\n", two->TID);   /* TID's are kept in a 32 bit int allowing up to 2^32 threads */
yield();    /* call yeild to create a contex switch */
printf("Out of yeild\n");
KillScheduler();    /* kill the scheduler not really required but there */
return 0;
}
