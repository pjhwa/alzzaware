#include "list.h"
/* this list adds to the end and removes from the front*/

void Append(struct list *thelist, void *toadd)
{
    struct item *newitem;
    newitem = malloc(sizeof(struct item));
    if(thelist->head==NULL)
    {
        newitem->data = toadd;
        newitem->next = NULL;
        thelist->head = newitem;
        thelist->tail = newitem;
    }
    else
    {
        newitem->data = toadd;
        newitem->next = NULL;
        thelist->tail->next = newitem;
        thelist->tail = newitem;
    }
    thelist->count++;
}

void *Remove(struct list *thelist)
{
    void *toret;
    struct item *listitem = thelist->head;

    if(thelist->count==0)
        return (void*) 0;

    if(thelist->head == NULL)
        return (void*) NULL;
    
    toret = thelist->head->data;

    if(thelist->head == thelist->tail)
    { 
        thelist->head = NULL;
        thelist->tail = NULL;
    }
    else
    {
        thelist->head = listitem->next;
    }
    free(listitem);
    thelist->count--;
    return toret;
}
