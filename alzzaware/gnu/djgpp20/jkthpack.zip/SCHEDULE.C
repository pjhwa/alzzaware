#include "schedule.h"
#include "list.h"

void CreateScheduler(void)
{
    scheduler = malloc(sizeof(struct list));
    scheduler->count = 0;
    scheduler->head = NULL;
    tobekilled = malloc(sizeof(struct thread));
    bigtid = 0;
    if(sizeof(int) == 16)
        MAXINT = 0xFF;
    if(sizeof(int) == 32)
        MAXINT = 0xFFFF;
}

void KillScheduler(void)
{
    free(scheduler);
    free(tobekilled);
}

void AddToReady(struct thread *toadd)
{
    toadd->threadstatus = READY;
    Append(scheduler, (void*)toadd);
}

struct thread * GetNextThread(void)
{
        return (struct thread *)Remove(scheduler);
}

void Start(struct thread *tostart)
{
    struct thread *oldthread;
   
    oldthread = current;
    oldthread->threadstatus = READY;
    current = tostart;
    current->threadstatus = RUNNING;
    
    SWITCH(oldthread, tostart);  
    /*need to kill threads that have exited    ill figure that one out later*/
}
