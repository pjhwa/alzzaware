#include "thread.h"
#include "signal.h"
#include <stdlib.h>
#include <stdio.h>
#include "schedule.h"

void test(void * it)
{
int x=0, i=0;
do{
for(x=0; x<=1; x++)
{
    printf("*4*\tx=%d\ti=%d\n", x, i);
}
    yield();
i++;
}while(i<=3);
    KillThread();
}

void another(void * j)
{
int x=0, i=0;
do{
for(x=0; x<=1; x++)
{
    printf("*5*\tx=%d\ti=%d\n", x, i);
}
    yield();
i++;
}while(i<=3);
    KillThread();
}

int main(void)
{
char temp;
struct thread *one;
struct thread *two;
struct thread *eek;
CreateScheduler();
CreateBlocker();
one = CreateThread(test, (void*)4);
two = CreateThread(another, (void*)5);
block(one);
block(two);
kick(two);
kick(one);
eek=0;
MakeMain(eek);
printf("one TID = %d\n", one->TID);
printf("two TID = %d\n", two->TID);
yield();
printf("Out of yeild\n");
KillScheduler();
return 0;
}
