#include "signal.h"
#include "schedule.h"
#include "thread.h"

int raisesig(int sig)
{
    void (*tocall)();

printf("Got here    %d\n\n", current->signals[sig-1]->handler);
    current->signals[sig-1]->handler();
    /*tocall();   */
}

int sigaction(int signo, struct sigaction *act, struct sigaction *oact)
{
    printf("In Sigaction TID=%d\n\n", current->TID);
    if(signo > 0 && signo < 10)    
    {
        current->signals[signo-1]->handler = act->handler;
        printf("act->handler=%d    kill_=%d\n\n", act->handler, kill_);
    }
    else
    {
        printf("Bad signal number!!\n\n");
    }
}
