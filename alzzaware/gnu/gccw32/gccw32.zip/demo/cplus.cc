#include <iostream.h>

class ERROR {};

void func() {
  throw ERROR();
}


main()
{
  int i;
  for (i =0;i < 10; i++)
    cout << "Hello World from C++" << i << "\n";


  try { func(); }

  catch (ERROR)
    {
      cout << " This came from an exception handler! \n";
    }
}

