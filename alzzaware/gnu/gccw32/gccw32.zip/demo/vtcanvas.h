//=======================================================================
//  vtcanvas.h - header for testCanvasPane
//  Copyright (C) 1995,1996  Bruce E. Wampler
//
//  This program is part of the V C++ GUI Framework example programs.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  (see COPYING) along with this program; if not, write to the Free
//  Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//=======================================================================

#ifndef VTCANVAS_H
#define VTCANVAS_H

#include <v/vtextcnv.h>

    class testCanvasPane : public vTextCanvasPane
      {
      public:		//---------------------------------------- public
	testCanvasPane();
	virtual ~testCanvasPane() {}

	// There is a $%@%# bug in g++, so we have to do these here

#ifdef BUG
	virtual void Clear(void)
		{ vTextCanvasPane::Clear(); }
	virtual void ClearRow(const int r, const int c)
		{vTextCanvasPane::ClearRow(r,c);}
	virtual void ClearToEnd(const int r, const int c)
		{vTextCanvasPane::ClearToEnd(r,c);}
  	virtual void DrawAttrText(const char* text, const ChrAttr attr)
		{vTextCanvasPane::DrawAttrText(text,attr);}
	virtual void DrawChar(const char chr, const ChrAttr attr)
		{vTextCanvasPane::DrawChar(chr,attr);}
  	virtual void DrawText(const char* text)
		{vTextCanvasPane::DrawText(text);}
	virtual void FontChanged(int newFont)
		{vTextCanvasPane::FontChanged(newFont);}
	virtual void ResizeText(const int rows, const int cols)
		{vTextCanvasPane::ResizeText(rows,cols);}
	virtual void Redraw(int x, int y, int height, int width)
		{vTextCanvasPane::Redraw(x,y,height,width);}
	virtual void Resize(int w, int h)
		{vTextCanvasPane::Resize(w,h);}
	virtual void TextMouseDown(int row, int col, int button)
		{vTextCanvasPane::TextMouseDown(row,col,button);}
	virtual void TextMouseUp(int row, int col, int button)
		{vTextCanvasPane::TextMouseUp(row,col,button);}
	virtual void TextMouseMove(int row, int col, int button)
		{vTextCanvasPane::TextMouseMove(row,col,button);}
#endif

      protected:	//--------------------------------------- protected

      private:		//--------------------------------------- private
      };
#endif
