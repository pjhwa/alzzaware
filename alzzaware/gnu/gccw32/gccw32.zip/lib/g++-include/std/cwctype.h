// The -*- C++ -*- wide character type header.
// This file is part of the GNU ANSI C++ Library.

#ifndef __CWCTYPE__
#define __CWCTYPE__
#include <wctype.h>
#endif
