// Main header for the -*- C++ -*- string classes.

#ifndef __STRING__
#define __STRING__

#include <std/bastring.h>

extern "C++" {
typedef basic_string <char> string;
// typedef basic_string <wchar_t> wstring;
} // extern "C++"

#endif
