#include <sys/fcntl.h>
#define O_NDELAY	_FNDELAY 
