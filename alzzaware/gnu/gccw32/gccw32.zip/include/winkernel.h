/*
   EXPORTS
   AddAtomA@4
   AddAtomW@4
   AddConsoleAliasA@12
   AddConsoleAliasW@12
   AllocConsole@0
   AreFileApisANSI@0
   BackupRead@28
   BackupSeek@24
   BackupWrite@28
   BaseAttachCompleteThunk@0
DONE       Beep@8
DONE       BeginUpdateResourceA@8
   BeginUpdateResourceW@8
   BuildCommDCBA@8
   BuildCommDCBAndTimeoutsA@12
   BuildCommDCBAndTimeoutsW@12
   BuildCommDCBW@8
   CallNamedPipeA@28
   CallNamedPipeW@28
   ClearCommBreak@4
   ClearCommError@12
   CloseConsoleHandle@4
DONE   CloseHandle@4
   CloseProfileUserMapping@0
   CmdBatNotification@4
   CommConfigDialogA@12
   CommConfigDialogW@12
   CompareFileTime@8
   CompareStringA@24
   CompareStringW@24
   ConnectNamedPipe@8
   ConsoleMenuControl@12
DONE       ContinueDebugEvent@12
   ConvertDefaultLocale@4
DONE   CopyFileA@12
   CopyFileW@12
   CreateConsoleScreenBuffer@20
DONE   CreateDirectoryA@8
   CreateDirectoryExA@12
   CreateDirectoryExW@12
   CreateDirectoryW@8
DONE       CreateEventA@16
   CreateEventW@16
DONE       CreateFileA@28
DONE       CreateFileMappingA@24
   CreateFileMappingW@24
DONE       CreateFileW@28
   CreateIoCompletionPort@16
   CreateMailslotA@16
   CreateMailslotW@16
DONE       CreateMutexA@12
   CreateMutexW@12
   CreateNamedPipeA@32
   CreateNamedPipeW@32
DONE       CreatePipe@16
DONE       CreateProcessA@40
   CreateProcessW@40
DONE       CreateRemoteThread@28
DONE       CreateSemaphoreA@16
   CreateSemaphoreW@16
   CreateTapePartition@16
DONE   CreateThread@24
   CreateVirtualBuffer@12
DONE       DebugActiveProcess@4
   DebugBreak@0
   DefineDosDeviceA@12
   DefineDosDeviceW@12
   DeleteAtom@4
DONE   DeleteCriticalSection@4
DONE   DeleteFileA@4
   DeleteFileW@4
   DeviceIoControl@32
   DisableThreadLibraryCalls@4
   DisconnectNamedPipe@4
   DosDateTimeToFileTime@12
   DuplicateConsoleHandle@16
DONE   DuplicateHandle@28
DONE       EndUpdateResourceA@8
   EndUpdateResourceW@8
DONE   EnterCriticalSection@4
   EnumCalendarInfoA@16
   EnumCalendarInfoW@16
   EnumDateFormatsA@12
   EnumDateFormatsW@12
   EnumResourceLanguagesA@20
   EnumResourceLanguagesW@20
   EnumResourceNamesA@16
   EnumResourceNamesW@16
   EnumResourceTypesA@12
   EnumResourceTypesW@12
   EnumSystemCodePagesA@8
   EnumSystemCodePagesW@8
   EnumSystemLocalesA@8
   EnumSystemLocalesW@8
   EnumTimeFormatsA@12
   EnumTimeFormatsW@12
   EraseTape@12
   EscapeCommFunction@8
DONE   ExitProcess@4
DONE       ExitThread@4
   ExitVDM@8
   ExpandEnvironmentStringsA@12
   ExpandEnvironmentStringsW@12
   ExpungeConsoleCommandHistoryA@4
   ExpungeConsoleCommandHistoryW@4
   ExtendVirtualBuffer@8
   FatalAppExitA@8
   FatalAppExitW@8
   FatalExit@4
   FileTimeToDosDateTime@12
   FileTimeToLocalFileTime@8
DONE       FileTimeToSystemTime@8
   FillConsoleOutputAttribute@20
   FillConsoleOutputCharacterA@20
   FillConsoleOutputCharacterW@20
   FindAtomA@4
   FindAtomW@4
DNOE   FindClose@4
   FindCloseChangeNotification@4
   FindFirstChangeNotificationA@12
   FindFirstChangeNotificationW@12
DONE       FindFirstFileA@8
   FindFirstFileW@8
   FindNextChangeNotification@4
DONE       FindNextFileA@8
   FindNextFileW@8
   FindResourceA@12
   FindResourceExA@16
   FindResourceExW@16
   FindResourceW@12
DONE       FlushConsoleInputBuffer@4
DONE   FlushFileBuffers@4
DONE       FlushInstructionCache@12
   FlushViewOfFile@8
   FoldStringA@20
   FoldStringW@20
   FormatMessageA@28
   FormatMessageW@28
   FreeConsole@0
DONE   FreeEnvironmentStringsA@4
   FreeEnvironmentStringsW@4
   FreeLibrary@4
   FreeLibraryAndExitThread@8
   FreeResource@4
   FreeVirtualBuffer@4
   GenerateConsoleCtrlEvent@8
   GetACP@0
   GetAtomNameA@12
   GetAtomNameW@12
   GetBinaryType@8
   GetBinaryTypeA@8
   GetBinaryTypeW@8
   GetCPInfo@8
   GetCommConfig@12
   GetCommMask@8
   GetCommModemStatus@8
   GetCommProperties@8
DONE       GetCommState@8
DONE       GetCommTimeouts@8
DONE   GetCommandLineA@0
   GetCommandLineW@0
   GetCompressedFileSizeA@8
   GetCompressedFileSizeW@8
DONE       GetComputerNameA@8
   GetComputerNameW@8
   GetConsoleAliasA@16
   GetConsoleAliasExesA@8
   GetConsoleAliasExesLengthA@0
   GetConsoleAliasExesLengthW@0
   GetConsoleAliasExesW@8
   GetConsoleAliasW@16
   GetConsoleAliasesA@12
   GetConsoleAliasesLengthA@4
   GetConsoleAliasesLengthW@4
   GetConsoleAliasesW@12
   GetConsoleCP@0
   GetConsoleCommandHistoryA@12
   GetConsoleCommandHistoryLengthA@4
   GetConsoleCommandHistoryLengthW@4
   GetConsoleCommandHistoryW@12
   GetConsoleCursorInfo@8
   GetConsoleDisplayMode@4
   GetConsoleFontInfo@16
   GetConsoleFontSize@8
   GetConsoleHardwareState@12
   GetConsoleInputWaitHandle@0
   GetConsoleMode@8
   GetConsoleOutputCP@0
   GetConsoleScreenBufferInfo@8
   GetConsoleTitleA@8
   GetConsoleTitleW@8
DONE   GetCurrencyFormatA@24
   GetCurrencyFormatW@24
   GetCurrentConsoleFont@12
   GetCurrentDirectoryA@8
   GetCurrentDirectoryW@8
DONE       GetCurrentProcess@0
DONE       GetCurrentProcessId@0
DONE       GetCurrentThread@0
DONE       GetCurrentThreadId@0
   GetDateFormatA@24
   GetDateFormatW@24
   GetDefaultCommConfigA@12
   GetDefaultCommConfigW@12
   GetDiskFreeSpaceA@20
   GetDiskFreeSpaceW@20
   GetDriveTypeA@4
   GetDriveTypeW@4
DONE   GetEnvironmentStrings@0
DONE   GetEnvironmentStringsA@0
DONE   GetEnvironmentStringsW@0
   GetEnvironmentVariableA@12
   GetEnvironmentVariableW@12
DONE   GetExitCodeProcess@8
DONE   GetExitCodeThread@8
DONE       GetFileAttributesA@4
   GetFileAttributesW@4
DONE   GetFileInformationByHandle@8
DONE       GetFileSize@8
   GetFileTime@16
DONE       GetFileType@4
DONE       GetFullPathNameA@16
   GetFullPathNameW@16
   GetHandleInformation@8
   GetLargestConsoleWindowSize@4
DONE   GetLastError@0
DONE       GetLocalTime@4
   GetLocaleInfoA@16
   GetLocaleInfoW@16
   GetLogicalDriveStringsA@8
   GetLogicalDriveStringsW@8
   GetLogicalDrives@0
   GetMailslotInfo@20
DONE     GetModuleFileNameA@12
   GetModuleFileNameW@12
DONE   GetModuleHandleA@4
   GetModuleHandleW@4
   GetNamedPipeHandleStateA@28
   GetNamedPipeHandleStateW@28
   GetNamedPipeInfo@20
   GetNextVDMCommand@4
   GetNumberFormatA@24
   GetNumberFormatW@24
   GetNumberOfConsoleFonts@0
   GetNumberOfConsoleInputEvents@8
   GetNumberOfConsoleMouseButtons@4
   GetOEMCP@0
   GetOverlappedResult@16
   GetPriorityClass@4
DONE       GetPrivateProfileIntA@16
DONE       GetPrivateProfileIntW@16
DONE       GetPrivateProfileSectionA@16
DONE       GetPrivateProfileSectionW@16
DONE       GetPrivateProfileStringA@24
DONE       GetPrivateProfileStringW@24
   GetProcAddress@8
   GetProcessAffinityMask@12
DONE   GetProcessHeap@0
   GetProcessHeaps@8
   GetProcessShutdownParameters@8
DONE   GetProcessTimes@20
   GetProcessWorkingSetSize@12
DONE       GetProfileIntA@12
DONE       GetProfileIntW@12
DONE       GetProfileSectionA@12
DONE       GetProfileSectionW@12
DONE       GetProfileStringA@20
DONE       GetProfileStringW@20
   GetQueuedCompletionStatus@20
   GetShortPathNameA@12
   GetShortPathNameW@12
   GetStartupInfoA@4
   GetStartupInfoW@4
DONE       GetStdHandle@4
   GetStringTypeA@20
   GetStringTypeExA@20
   GetStringTypeExW@20
   GetStringTypeW@16
   GetSystemDefaultLCID@0
   GetSystemDefaultLangID@0
   GetSystemDirectoryA@8
   GetSystemDirectoryW@8
DONE       GetSystemInfo@4
DONE       GetSystemTime@4
   GetSystemTimeAdjustment@12
   GetTapeParameters@16
   GetTapePosition@20
   GetTapeStatus@4
   GetTempFileNameA@16
   GetTempFileNameW@16
   GetTempPathA@8
   GetTempPathW@8
DONE       GetThreadContext@8
   GetThreadLocale@0
   GetThreadPriority@4
   GetThreadSelectorEntry@12
   GetThreadTimes@20
DONE       GetTickCount@0
   GetTimeFormatA@24
   GetTimeFormatW@24
DONE       GetTimeZoneInformation@4
   GetUserDefaultLCID@0
   GetUserDefaultLangID@0
   GetVDMCurrentDirectories@8
   GetVersion@0
   GetVersionExA@4
   GetVersionExW@4
   GetVolumeInformationA@32
   GetVolumeInformationW@32
   GetWindowsDirectoryA@8
   GetWindowsDirectoryW@8
   GlobalAddAtomA@4
   GlobalAddAtomW@4
DONE     GlobalAlloc@8
   GlobalCompact@4
   GlobalDeleteAtom@4
   GlobalFindAtomA@4
   GlobalFindAtomW@4
   GlobalFix@4
   GlobalFlags@4
DONE     GlobalFree@4
   GlobalGetAtomNameA@12
   GlobalGetAtomNameW@12
   GlobalHandle@4
DONE     GlobalLock@4
   GlobalMemoryStatus@4
DONE   GlobalReAlloc@12
   GlobalSize@4
   GlobalUnWire@4
   GlobalUnfix@4
DONE     GlobalUnlock@4
   GlobalWire@4
DONE       HeapAlloc@12
   HeapCompact@8
   HeapCreate@12
   HeapDestroy@4
DONE       HeapFree@12
   HeapLock@4
   HeapReAlloc@16
   HeapSize@12
   HeapUnlock@4
   HeapValidate@12
   HeapWalk@8
   InitAtomTable@4
DONE   InitializeCriticalSection@4
   InterlockedDecrement@4
   InterlockedExchange@8
   InterlockedIncrement@4
   InvalidateConsoleDIBits@8
   IsBadCodePtr@4
   IsBadHugeReadPtr@8
   IsBadHugeWritePtr@8
   IsBadReadPtr@8
   IsBadStringPtrA@8
   IsBadStringPtrW@8
   IsBadWritePtr@8
   IsDBCSLeadByte@4
   IsDBCSLeadByteEx@8
   IsValidCodePage@4
   IsValidLocale@8
   LCMapStringA@24
   LCMapStringW@24
DONE   LeaveCriticalSection@4
DONE       LoadLibraryA@4
   LoadLibraryExA@12
   LoadLibraryExW@12
   LoadLibraryW@4
   LoadModule@8
   LoadResource@8
DONE   LocalAlloc@8
   LocalCompact@4
DONE       LocalFileTimeToFileTime@8
   LocalFlags@4
DONE   LocalFree@4
   LocalHandle@4
   LocalLock@4
DONE   LocalReAlloc@12
   LocalShrink@8
   LocalSize@4
   LocalUnlock@4
   LockFile@20
   LockFileEx@24
   LockResource@4
DONE       MapViewOfFile@20
DONE       MapViewOfFileEx@24
DONE       MoveFileA@8
DONE      MoveFileExA@12
   MoveFileExW@12
   MoveFileW@8
   MulDiv@12
   MultiByteToWideChar@24
   OpenConsoleW@16
   OpenEventA@12
   OpenEventW@12
   OpenFile@12
DONE       OpenFileMappingA@12
   OpenFileMappingW@12
   OpenMutexA@12
   OpenMutexW@12
   OpenProcess@12
   OpenProfileUserMapping@0
   OpenSemaphoreA@12
   OpenSemaphoreW@12
   OutputDebugStringA@4
   OutputDebugStringW@4
   PeekConsoleInputA@16
   PeekConsoleInputW@16
   PeekNamedPipe@24
   PrepareTape@12
DONE   PulseEvent@4
DONE       PurgeComm@8
   QueryDosDeviceA@12
   QueryDosDeviceW@12
   QueryPerformanceCounter@4
   QueryPerformanceFrequency@4
   QueryWin31IniFilesMappedToRegistry@16
DONE       RaiseException@16
   ReadConsoleA@20
   ReadConsoleInputA@16
   ReadConsoleInputW@16
   ReadConsoleOutputA@20
   ReadConsoleOutputAttribute@20
   ReadConsoleOutputCharacterA@20
   ReadConsoleOutputCharacterW@20
   ReadConsoleOutputW@20
   ReadConsoleW@20
DONE   ReadFile@20
   ReadFileEx@20
DONE       ReadProcessMemory@20
   RegisterConsoleVDM@44
   RegisterWaitForInputIdle@4
   RegisterWowBaseHandlers@4
   RegisterWowExec@4
DONE       ReleaseMutex@4
DONE       ReleaseSemaphore@12
DONE   RemoveDirectoryA@4
   RemoveDirectoryW@4
DONE       ResetEvent@4
DONE       ResumeThread@4
   RtlFillMemory@12
   RtlMoveMemory@12
DONE   RtlUnwind@16
   RtlZeroMemory@8
   ScrollConsoleScreenBufferA@20
   ScrollConsoleScreenBufferW@20
   SearchPathA@24
   SearchPathW@24
   SetCommBreak@4
   SetCommConfig@12
   SetCommMask@8
DONE       SetCommState@8
DONE       SetCommTimeouts@8
   SetComputerNameA@4
   SetComputerNameW@4
   SetConsoleActiveScreenBuffer@4
   SetConsoleCP@4
   SetConsoleCommandHistoryMode@4
   SetConsoleCtrlHandler@8
   SetConsoleCursor@8
   SetConsoleCursorInfo@8
   SetConsoleCursorPosition@8
   SetConsoleDisplayMode@12
   SetConsoleFont@8
   SetConsoleHardwareState@12
   SetConsoleKeyShortcuts@16
   SetConsoleMaximumWindowSize@8
   SetConsoleMenuClose@4
   SetConsoleMode@8
   SetConsoleNumberOfCommandsA@8
   SetConsoleNumberOfCommandsW@8
   SetConsoleOutputCP@4
   SetConsolePalette@12
   SetConsoleScreenBufferSize@8
DONE       SetConsoleTextAttribute@8
   SetConsoleTitleA@4
   SetConsoleTitleW@4
   SetConsoleWindowInfo@12
DONE   SetCurrentDirectoryA@4
   SetCurrentDirectoryW@4
   SetDefaultCommConfigA@12
   SetDefaultCommConfigW@12
DONE       SetEndOfFile@4
   SetEnvironmentVariableA@8
   SetEnvironmentVariableW@8
   SetErrorMode@4
DONE       SetEvent@4
   SetFileApisToANSI@0
   SetFileApisToOEM@0
DONE       SetFileAttributesA@8
   SetFileAttributesW@8
DONE       SetFilePointer@16
DONE       SetFileTime@16
   SetHandleCount@4
   SetHandleInformation@12
   SetLastConsoleEventActive@0
   SetLastError@4
   SetLocalTime@4
   SetLocaleInfoA@12
   SetLocaleInfoW@12
   SetMailslotInfo@8
   SetNamedPipeHandleState@16
   SetPriorityClass@8
   SetProcessShutdownParameters@8
   SetProcessWorkingSetSize@12
   SetStdHandle@8
   SetSystemTime@4
   SetSystemTimeAdjustment@8
   SetTapeParameters@12
   SetTapePosition@24
   SetThreadAffinityMask@8
   SetThreadContext@8
   SetThreadLocale@4
   SetThreadPriority@8
   SetTimeZoneInformation@4
   SetUnhandledExceptionFilter@4
   SetVDMCurrentDirectories@8
   SetVolumeLabelA@8
   SetVolumeLabelW@8
   SetupComm@12
   ShowConsoleCursor@8
   SizeofResource@8
DONE       Sleep@4
   SleepEx@8
DONE       SuspendThread@4
DONE       SystemTimeToFileTime@8
   SystemTimeToTzSpecificLocalTime@12
   TerminateProcess@8
DONE   TerminateThread@8
   TlsAlloc@0
   TlsFree@4
   TlsGetValue@4
   TlsSetValue@8
   TransactNamedPipe@28
   TransmitCommChar@8
   TrimVirtualBuffer@4
   UnhandledExceptionFilter@4
   UnlockFile@20
   UnlockFileEx@20
   UnmapViewOfFile@4
DONE       UpdateResourceA@24
   UpdateResourceW@24
   VDMConsoleOperation@8
   VDMOperationStarted@4
   VerLanguageNameA@12
   VerLanguageNameW@12
   VerifyConsoleIoHandle@4
   VirtualAlloc@16
   VirtualBufferExceptionHandler@12
   VirtualFree@12
   VirtualLock@8
   VirtualProtect@16
   VirtualProtectEx@20
   VirtualQuery@12
   VirtualQueryEx@16
   VirtualUnlock@8
   WaitCommEvent@12
DONE       WaitForDebugEvent@8
DONE   WaitForMultipleObjects@16
   WaitForMultipleObjectsEx@20
DONE   WaitForSingleObject@8
   WaitForSingleObjectEx@12
   WaitNamedPipeA@8
   WaitNamedPipeW@8
DONE       WideCharToMultiByte@32
   WinExec@8
   WriteConsoleA@20
   WriteConsoleInputA@16
   WriteConsoleInputVDMA@16
   WriteConsoleInputVDMW@16
   WriteConsoleInputW@16
   WriteConsoleOutputA@20
   WriteConsoleOutputAttribute@20
   WriteConsoleOutputCharacterA@20
   WriteConsoleOutputCharacterW@20
   WriteConsoleOutputW@20
   WriteConsoleW@20
DONE   WriteFile@20
   WriteFileEx@20
   WritePrivateProfileSectionA@12
   WritePrivateProfileSectionW@12
   WritePrivateProfileStringA@16
   WritePrivateProfileStringW@16
DONE       WriteProcessMemory@20
   WriteProfileSectionA@8
   WriteProfileSectionW@8
DONE   WriteProfileStringA@12
DONE   WriteProfileStringW@12
   WriteTapemark@16
DONE       _hread@12
DONE       _hwrite@12
DONE       _lclose@4
DONE       _lcreat@8
DONE       _llseek@12
DONE       _lopen@8
DONE       _lread@12
DONE       _lwrite@12
DONE     lstrcat@8
   lstrcatA@8
   lstrcatW@8
   lstrcmp@8
   lstrcmpA@8
   lstrcmpW@8
   lstrcmpi@8
DONE       lstrcmpiA@8
DONE       lstrcmpiW@8
DONE     lstrcpy@8
DONE       lstrcpyA@8
DONE       lstrcpyW@8
DONE       lstrcpyn@12
DONE       lstrcpynA@12
DONE       lstrcpynW@12
DONE     lstrlen@4
DONE       lstrlenA@4
DONE       lstrlenW@4
 */



#ifdef UNICODE
#define GetProfileInt  GetProfileIntW
#define lstrcpy lstrcpyW
#define lstrlen lstrlenW
#define lstrcat lstrcatW
#define CreateFile CreateFileW
#define lstrcmpi lstrcmpiW
#define GetProfileString  GetProfileStringW
#define WriteProfileString  WriteProfileStringW
#define GetProfileSection  GetProfileSectionW
#define WriteProfileSection  WriteProfileSectionW
#define GetPrivateProfileInt  GetPrivateProfileIntW
#define GetPrivateProfileString  GetPrivateProfileStringW
#define WritePrivateProfileString  WritePrivateProfileStringW
#define GetPrivateProfileSection  GetPrivateProfileSectionW
#define WritePrivateProfileSection  WritePrivateProfileSectionW
#define CreateDirectory  CreateDirectoryW
#else
#define CreateDirectory  CreateDirectoryA
#define GetModuleFileName GetModuleFileNameA
#define BeginUpdateResource BeginUpdateResourceA
#define CreateFile CreateFileA
#define CreateProcess CreateProcessA
#define CreateSemaphore CreateSemaphoreA
#define EndUpdateResource EndUpdateResourceA
#define FindFirstFile FindFirstFileA
#define FindNextFile FindNextFileA
#define GetComputerName GetComputerNameA
#define GetFullPathName GetFullPathNameA
#define GetPrivateProfileInt  GetPrivateProfileIntA
#define GetPrivateProfileSection  GetPrivateProfileSectionA
#define GetPrivateProfileString  GetPrivateProfileStringA
#define GetProfileInt  GetProfileIntA
#define GetProfileSection  GetProfileSectionA
#define GetProfileString  GetProfileStringA
#define LoadLibrary LoadLibraryA
#define MoveFile MoveFileA
#define MoveFileEx MoveFileExA
#define OpenFileMapping OpenFileMappingA
#define UpdateResource UpdateResourceA
#define WIN32_FIND_DATA WIN32_FIND_DATAA
#define WritePrivateProfileSection  WritePrivateProfileSectionA
#define WritePrivateProfileString  WritePrivateProfileStringA
#define WriteProfileSection  WriteProfileSectionA
#define WriteProfileString  WriteProfileStringA
#define lstrcmpi lstrcmpiA
#define lstrlen lstrlenA
#endif

DECLARE_HANDLE (HGLOBAL);

typedef struct
  {
    /* Two ways for read timeouts  

       t=MIN(way1, way2)

       way1 = ReadIntervalTimeout
       way2 = ncharsread * ReadTotalTimeoutMultiplier + ReadTotalTimeoutContant

       all times in milisecs */

    DWORD ReadIntervalTimeout;
    DWORD ReadTotalTimeoutMultiplier;
    DWORD ReadTotalTimeoutConstant;
    DWORD WriteTotalTimeoutMultiplier;
    DWORD WriteTotalTimeoutConstant;
  }
COMMTIMEOUTS;


#define CBR_110             110
#define CBR_300             300
#define CBR_600             600
#define CBR_1200            1200
#define CBR_2400            2400
#define CBR_4800            4800
#define CBR_9600            9600
#define CBR_14400           14400
#define CBR_19200           19200
#define CBR_38400           38400
#define CBR_56000           56000
#define CBR_57600           57600
#define CBR_115200          115200
#define CBR_128000          128000
#define CBR_256000          256000

/* This may have to be packed, all those bitfields make me edgy, 
   I've only looked at the baudrate */
#define NOPARITY            0
#define ODDPARITY           1
#define EVENPARITY          2
#define MARKPARITY          3
#define SPACEPARITY         4

typedef struct
  {
    DWORD DCBlength;
    DWORD BaudRate;
    DWORD fBinary:1;
    DWORD fParity:1;
    DWORD fOutxCtsFlow:1;
    DWORD fOutxDsrFlow:1;
    DWORD fDtrControl:2;
    DWORD fDsrSensitivity:1;
    DWORD fTXContinueOnXoff:1;
    DWORD fOutX:1;
    DWORD fInX:1;
    DWORD fErrorChar:1;
    DWORD fNull:1;
    DWORD fRtsControl:2;
    DWORD fAbortOnError:1;
    DWORD fDummy2:17;
    WORD res1;
    WORD XonLim;
    WORD XoffLim;
    BYTE ByteSize;
    BYTE Parity;
    BYTE StopBits;
    char XonChar;
    char XoffChar;
    char ErrorChar;
    char EofChar;
    char EvtChar;
    int res2;
  }
DCB;



/* Abort = Terminate 
   Clear = flush */
#define PURGE_RXABORT 2
#define PURGE_RXCLEAR 8
#define PURGE_TXABORT 1
#define PURGE_TXCLEAR 4

BOOL WINAPI PurgeComm (HANDLE hdev, DWORD action);


/* flags for createprocess creation */
#define DEBUG_PROCESS               0x00000001
#define DEBUG_ONLY_THIS_PROCESS     0x00000002
#define CREATE_SUSPENDED            0x00000004
#define DETACHED_PROCESS            0x00000008
#define CREATE_NEW_CONSOLE          0x00000010
#define NORMAL_PRIORITY_CLASS       0x00000020
#define IDLE_PRIORITY_CLASS         0x00000040
#define HIGH_PRIORITY_CLASS         0x00000080
#define REALTIME_PRIORITY_CLASS     0x00000100
#define CREATE_NEW_PROCESS_GROUP    0x00000200
#define CREATE_UNICODE_ENVIRONMENT  0x00000400

#define STARTF_USESHOWWINDOW    0x00000001
#define STARTF_USESIZE          0x00000002
#define STARTF_USEPOSITION      0x00000004
#define STARTF_USECOUNTCHARS    0x00000008
#define STARTF_USEFILLATTRIBUTE 0x00000010
#define STARTF_RUNFULLSCREEN    0x00000020
#define STARTF_FORCEONFEEDBACK  0x00000040
#define STARTF_FORCEOFFFEEDBACK 0x00000080
#define STARTF_USESTDHANDLES    0x00000100

typedef struct
  {
    DWORD cb;
    char *lpReserved;
    char *lpDesktop;
    char *lpTitle;
    DWORD dwX;
    DWORD dwY;
    DWORD dwXSize;
    DWORD dwYSize;
    DWORD dwXCountChars;
    DWORD dwYCountChars;
    DWORD dwFillAttribute;
    DWORD dwFlags;
    WORD wShowWindow;
    WORD cbReserved2;
    LPBYTE lpReserved2;
    HANDLE hStdInput;
    HANDLE hStdOutput;
    HANDLE hStdError;
  }
STARTUPINFO;


typedef struct
  {
    HANDLE hProcess;
    HANDLE hThread;
    DWORD dwProcessId;
    DWORD dwThreadId;
  }
PROCESS_INFORMATION;


DWORD WINAPI CreateProcessA
  (const char *name,
   char *commandline,
   void *processatts,
   void *threadatts,
   DWORD inherit,
   DWORD creation,
   void *environ,
   char *currentdir,
   STARTUPINFO * startup,
   PROCESS_INFORMATION * processinfo);



DWORD WINAPI CreateProcessA
  (const char *name,
   char *commandline,
   void *processatts,
   void *threadatts,
   DWORD inherit,
   DWORD creation,
   void *environ,
   char *currentdir,
   STARTUPINFO * startup,
   PROCESS_INFORMATION * processinfo);



#define EXCEPTION_MAXIMUM_PARAMETERS 15

/* ExceptionCodes */


#define EXCEPTION_ACCESS_VIOLATION       STATUS_ACCESS_VIOLATION
#define EXCEPTION_BREAKPOINT              STATUS_BREAKPOINT
#define EXCEPTION_SINGLE_STEP STATUS_SINGLE_STEP
#define EXCEPTION_CTRL_C


typedef struct __erec
  {
    DWORD ExceptionCode;
    DWORD ExceptionFlags;
    struct __erec *ExceptionRecord;
    void *ExceptionAddress;
    DWORD NumberParameters;
    DWORD ExceptionInformation[EXCEPTION_MAXIMUM_PARAMETERS];
  }
EXCEPTION_RECORD;

/* values for dwDebugEventCode */

#define EXCEPTION_DEBUG_EVENT       1
#define CREATE_THREAD_DEBUG_EVENT   2
#define CREATE_PROCESS_DEBUG_EVENT  3
#define EXIT_THREAD_DEBUG_EVENT     4
#define EXIT_PROCESS_DEBUG_EVENT    5
#define LOAD_DLL_DEBUG_EVENT        6
#define UNLOAD_DLL_DEBUG_EVENT      7
#define OUTPUT_DEBUG_STRING_EVENT   8
#define RIP_EVENT                   9

typedef WINAPI DWORD (THREAD_START_ROUTINE) (void *lpThreadParameter);


typedef struct
  {
    EXCEPTION_RECORD ExceptionRecord;
    DWORD dwFirstChance;
  }
EXCEPTION_DEBUG_INFO;

typedef struct
  {
    HANDLE hThread;
    VOID *lpThreadLocalBase;
    THREAD_START_ROUTINE *lpStartAddress;
  }
CREATE_THREAD_DEBUG_INFO;

typedef struct
  {
    HANDLE hFile;
    HANDLE hProcess;
    HANDLE hThread;
    LPVOID lpBaseOfImage;
    DWORD dwDebugInfoFileOffset;
    DWORD nDebugInfoSize;
    LPVOID lpThreadLocalBase;
    THREAD_START_ROUTINE *lpStartAddress;
    void *lpImageName;
    WORD fUnicode;
  }
CREATE_PROCESS_DEBUG_INFO;

typedef struct
  {
    HANDLE hFile;
    void *lpBaseOfDll;
    DWORD dwDebugInfoFileOffset;
    DWORD nDebugInfoSize;
    void *lpImageName;		/* pointer into target process space */
    WORD fUnicode;		/* I wonder what the 'f' stands for ;) */
  }
LOAD_DLL_DEBUG_INFO;

typedef struct
  {
    DWORD dwExitCode;
  }
EXIT_PROCESS_DEBUG_INFO;

typedef struct
  {
    DWORD dwExitCode;
  }
EXIT_THREAD_DEBUG_INFO;

typedef struct 
  {
    void * lpBaseOfDll;
  } 
UNLOAD_DLL_DEBUG_INFO;

typedef struct 
  {
    char * lpDebugStringData;
    WORD fUnicode;
    WORD nDebugStringLength;
  } 
OUTPUT_DEBUG_STRING_INFO;

typedef struct 
  {
    DWORD dwError;
    DWORD dwType;
  } 
RIP_INFO;

typedef struct
  {
    DWORD dwDebugEventCode;
    DWORD dwProcessId;
    DWORD dwThreadId;
    union 
      {
	EXCEPTION_DEBUG_INFO Exception;
	CREATE_THREAD_DEBUG_INFO CreateThread;
	CREATE_PROCESS_DEBUG_INFO CreateProcessInfo;
	LOAD_DLL_DEBUG_INFO LoadDll;
	EXIT_PROCESS_DEBUG_INFO ExitProcess;
	EXIT_THREAD_DEBUG_INFO ExitThread;
	UNLOAD_DLL_DEBUG_INFO UnloadDll;
	OUTPUT_DEBUG_STRING_INFO DebugString;
	RIP_INFO RipInfo;
      }
    u;
  }
DEBUG_EVENT;


BOOL WINAPI WaitForDebugEvent (DEBUG_EVENT * p, DWORD timeout);

#define DBG_CONTINUE                    0x00010002
#define DBG_TERMINATE_THREAD            0x40010003
#define DBG_TERMINATE_PROCESS           0x40010004
#define DBG_CONTROL_C                   0x40010005
#define DBG_CONTROL_BREAK               0x40010008
#define DBG_EXCEPTION_NOT_HANDLED       0x80010001



#ifdef __PPC__

#define CONTEXT_CONTROL         1L
#define CONTEXT_FLOATING_POINT  2L
#define CONTEXT_INTEGER         4L
#define CONTEXT_DEBUG_REGISTERS	8L

#define CONTEXT_FULL (CONTEXT_CONTROL | CONTEXT_FLOATING_POINT | CONTEXT_INTEGER)
#define CONTEXT_DEBUGGER (CONTEXT_FULL)

typedef struct
  {
    /* Floating point registers returned when CONTEXT_FLOATING_POINT is set */
    double Fpr0;
    double Fpr1;
    double Fpr2;
    double Fpr3;
    double Fpr4;
    double Fpr5;
    double Fpr6;
    double Fpr7;
    double Fpr8;
    double Fpr9;
    double Fpr10;
    double Fpr11;
    double Fpr12;
    double Fpr13;
    double Fpr14;
    double Fpr15;
    double Fpr16;
    double Fpr17;
    double Fpr18;
    double Fpr19;
    double Fpr20;
    double Fpr21;
    double Fpr22;
    double Fpr23;
    double Fpr24;
    double Fpr25;
    double Fpr26;
    double Fpr27;
    double Fpr28;
    double Fpr29;
    double Fpr30;
    double Fpr31;
    double Fpscr;

    /* Integer registers returned when CONTEXT_INTEGER is set.  */
    DWORD Gpr0;
    DWORD Gpr1;
    DWORD Gpr2;
    DWORD Gpr3;
    DWORD Gpr4;
    DWORD Gpr5;
    DWORD Gpr6;
    DWORD Gpr7;
    DWORD Gpr8;
    DWORD Gpr9;
    DWORD Gpr10;
    DWORD Gpr11;
    DWORD Gpr12;
    DWORD Gpr13;
    DWORD Gpr14;
    DWORD Gpr15;
    DWORD Gpr16;
    DWORD Gpr17;
    DWORD Gpr18;
    DWORD Gpr19;
    DWORD Gpr20;
    DWORD Gpr21;
    DWORD Gpr22;
    DWORD Gpr23;
    DWORD Gpr24;
    DWORD Gpr25;
    DWORD Gpr26;
    DWORD Gpr27;
    DWORD Gpr28;
    DWORD Gpr29;
    DWORD Gpr30;
    DWORD Gpr31;

    DWORD Cr;			/* Condition register */
    DWORD Xer;			/* Fixed point exception register */

    /* The following are set when CONTEXT_CONTROL is set.  */
    DWORD Msr;			/* Machine status register */
    DWORD Iar;			/* Instruction address register */
    DWORD Lr;			/* Link register */
    DWORD Ctr;			/* Control register */

    /* Control which context values are returned */
    DWORD ContextFlags;
    DWORD Fill[3];

    /* Registers returned if CONTEXT_DEBUG_REGISTERS is set.  */
    DWORD Dr0;                          /* Breakpoint Register 1 */
    DWORD Dr1;                          /* Breakpoint Register 2 */
    DWORD Dr2;                          /* Breakpoint Register 3 */
    DWORD Dr3;                          /* Breakpoint Register 4 */
    DWORD Dr4;                          /* Breakpoint Register 5 */
    DWORD Dr5;                          /* Breakpoint Register 6 */
    DWORD Dr6;                          /* Debug Status Register */
    DWORD Dr7;                          /* Debug Control Register */
}
CONTEXT;


#else


/* The doc refered me to winnt.h, so I had to look.. */
#define SIZE_OF_80387_REGISTERS      80

typedef struct
  {
    DWORD ControlWord;
    DWORD StatusWord;
    DWORD TagWord;
    DWORD ErrorOffset;
    DWORD ErrorSelector;
    DWORD DataOffset;
    DWORD DataSelector;
    BYTE RegisterArea[SIZE_OF_80387_REGISTERS];
    DWORD Cr0NpxState;
  }
FLOATING_SAVE_AREA;

/* Values for contextflags */
#define CONTEXT_i386    0x10000
#define CONTEXT_CONTROL         (CONTEXT_i386 | 1)	
#define CONTEXT_INTEGER         (CONTEXT_i386 | 2)	
#define CONTEXT_SEGMENTS        (CONTEXT_i386 | 4)	
#define CONTEXT_FLOATING_POINT  (CONTEXT_i386 | 8)	
#define CONTEXT_DEBUG_REGISTERS (CONTEXT_i386 | 0x10)
#define CONTEXT_FULL (CONTEXT_CONTROL | CONTEXT_INTEGER | CONTEXT_SEGMENTS)

/* our own invention */
#define CONTEXT_DEBUGGER (CONTEXT_FULL | CONTEXT_FLOATING_POINT)

typedef struct
  {
    DWORD ContextFlags;

    DWORD Dr0;
    DWORD Dr1;
    DWORD Dr2;
    DWORD Dr3;
    DWORD Dr6;
    DWORD Dr7;

    FLOATING_SAVE_AREA FloatSave;

    DWORD SegGs;
    DWORD SegFs;
    DWORD SegEs;
    DWORD SegDs;


    DWORD Edi;
    DWORD Esi;
    DWORD Ebx;
    DWORD Edx;
    DWORD Ecx;
    DWORD Eax;

    DWORD Ebp;
    DWORD Eip;
    DWORD SegCs;
#define FLAG_TRACE_BIT 0x100
    DWORD EFlags;
    DWORD Esp;
    DWORD SegSs;

  }
CONTEXT;

#endif

BOOL WINAPI GetThreadContext (HANDLE threadh, CONTEXT * cont);
BOOL WINAPI SetThreadContext (HANDLE threadh, CONTEXT * cont);
BOOL WINAPI FlushInstructionCache (HANDLE process, DWORD p, DWORD len);

DWORD WINAPI GetTickCount ();

typedef struct
  {
    WORD wYear;
    WORD wMonth;
    WORD wDayOfWeek;
    WORD wDay;
    WORD wHour;
    WORD wMinute;
    WORD wSecond;
    WORD wMilliseconds;
  }
SYSTEMTIME;





BOOL WINAPI LocalFileTimeToFileTime (const FILETIME *, FILETIME *);
BOOL WINAPI SystemTimeToFileTime (const SYSTEMTIME *, FILETIME *);


#define CP_ACP		0
#define CP_OEMCP	1
#define CP_MACCP	2


int WINAPI WideCharToMultiByte (UINT page, DWORD flags, WCHAR * src, int srclen,
			     char *dst, int dstlen, char *def, BOOL usedef);


BOOL WINAPI DebugActiveProcess (DWORD pid);


#define MOVEFILE_REPLACE_EXISTING   1
#define MOVEFILE_COPY_ALLOWED       2
#define MOVEFILE_DELAY_UNTIL_REBOOT 4

BOOL WINAPI MoveFileExA (const char *from, const char *to, int flags);
BOOL WINAPI MoveFile (const char *from, const char *to);
WINAPI DWORD GetFileType (HANDLE x);
DWORD WINAPI GetFileAttributesA (const char *);
DWORD WINAPI SetFileAttributesA (const char *, DWORD atts);
typedef struct
  {
    DWORD nLength;
    void *lpSecurityDescriptor;
    BOOL bInheritHandle;
  }
SECURITY_ATTRIBUTES;
BOOL WINAPI CreatePipe (HANDLE *, HANDLE *, SECURITY_ATTRIBUTES *, DWORD);

WINAPI HANDLE CreateFileMappingA (HANDLE h, SECURITY_ATTRIBUTES * ats,
		       DWORD pot, DWORD sh, DWORD hlow, const char *lpName);


#define FILE_MAP_WRITE      2
#define FILE_MAP_READ       4
#define FILE_MAP_ALL_ACCESS (FILE_MAP_READ|FILE_MAP_WRITE)

WINAPI void *MapViewOfFile (HANDLE handle,
			    DWORD access,
			    DWORD offhi,
			    DWORD offlo,
			    DWORD size);

WINAPI void *MapViewOfFileEx (HANDLE handle,
			      DWORD access,
			      DWORD offhi,
			      DWORD offlo,
			      DWORD size,
			      DWORD st);

WINAPI HANDLE OpenFileMappingA (DWORD access, BOOL inheirit, const char *fname);
WINAPI HANDLE GetCurrentThread ();
WINAPI DWORD GetCurrentThreadId ();
WINAPI DWORD ResumeThread (HANDLE);
WINAPI HANDLE CreateSemaphoreA (SECURITY_ATTRIBUTES *, LONG init, LONG max, const char *name);

WINAPI BOOL SetEvent (HANDLE);
WINAPI BOOL ResetEvent (HANDLE);
WINAPI BOOL ReleaseSemaphore (HANDLE h, LONG c, LONG * prev_c);
WINAPI DWORD SuspendThread (HANDLE);

WINAPI HANDLE CreateEventA (SECURITY_ATTRIBUTES *, BOOL au, BOOL on, const char *name);
WINAPI HANDLE CreateRemoteThread (HANDLE ph,
				  SECURITY_ATTRIBUTES *,
				  DWORD istack,
				  void (*func) (),
				  void *arg,
				  DWORD flags,
				  DWORD * res);
WINAPI void ExitThread (DWORD);
WINAPI HANDLE CreateMutexA (SECURITY_ATTRIBUTES *, BOOL on, const char *);
WINAPI BOOL ReleaseMutex (HANDLE);

WINAPI BOOL SetConsoleTextAttribute (HANDLE, DWORD);
WINAPI BOOL GetComputerNameA (char *, DWORD * size);

#define FILE_BEGIN 0
#define FILE_CURRRENT 1
#define FILE_END 2

DWORD WINAPI SetFilePointer (HANDLE, DWORD, DWORD, DWORD);

WINAPI void *HeapAlloc (HANDLE h, DWORD f, DWORD size);

WINAPI BOOL HeapFree (HANDLE h, DWORD flags, void *p);
WINAPI BOOL SetEndOfFile (HANDLE h);
WINAPI void GetSystemTime (SYSTEMTIME * p);
WINAPI void GetLocalTime (SYSTEMTIME *);

typedef struct
  {
    LONG Bias;
    WCHAR StandardName[32];
    SYSTEMTIME StandardDate;
    LONG StandardBias;
    WCHAR DaylightName[32];
    SYSTEMTIME DaylightDate;
    LONG DaylightBias;
  }
TIME_ZONE_INFORMATION;

#define TIME_ZONE_ID_UNKNOWN 0
#define TIME_ZONE_ID_STANDARD 1
#define TIME_ZONE_ID_DAYLIGHT 2

#define PROCESSOR_ARCHITECTURE_INTEL 0
#define PROCESSOR_ARCHITECTURE_MIPS  1
#define PROCESSOR_ARCHITECTURE_ALPHA 2
#define PROCESSOR_ARCHITECTURE_PPC   3

typedef struct
  {
    union
      {
	DWORD dwOemID;
	struct
	  {
	    WORD wProcessorArchitecture;
	    WORD wReserved;
	  }
	s;
      }
    u;
    DWORD dwPageSize;
    void *lpMinimumApplicationAddress;
    void *lpMaximumApplicationAddress;
    DWORD dwActiveProcessorMask;
    DWORD dwNumberOfProcessors;
    DWORD dwProcessorType;
    DWORD dwAllocationGranularity;
    WORD wProcessorLevel;
    WORD wProcessorRevision;
  }
SYSTEM_INFO;

WINAPI DWORD GetTimeZoneInformation (TIME_ZONE_INFORMATION * z);
WINAPI void GetSystemInfo (SYSTEM_INFO *);
WINAPI BOOL SetFileTime (HANDLE, FILETIME *, FILETIME *, FILETIME *);
WINAPI const int GetCurrentProcessId (void);
WINAPI int TerminateProcess (HANDLE h, int ret);
WINAPI const HANDLE GetCurrentProcess (void);
WINAPI BOOL FileTimeToSystemTime (const FILETIME *, SYSTEMTIME *);

WINAPI BOOL Beep (DWORD f, DWORD time);
WINAPI BOOL FlushConsoleInputBuffer (HANDLE h);
WINAPI BOOL FlushFileBuffers (HANDLE h);

WINAPI HANDLE BeginUpdateResourceA (const char *, BOOL);
WINAPI BOOL UpdateResourceA (HANDLE, const char *, const char *, int /* should be word */ , void *, DWORD);
WINAPI BOOL EndUpdateResourceA (HANDLE, BOOL);

WINAPI HANDLE LoadLibraryA (const char *);


#define FILE_FLAG_WRITE_THROUGH         0x80000000
#define FILE_FLAG_OVERLAPPED            0x40000000
#define FILE_FLAG_NO_BUFFERING          0x20000000
#define FILE_FLAG_RANDOM_ACCESS         0x10000000
#define FILE_FLAG_SEQUENTIAL_SCAN       0x08000000
#define FILE_FLAG_DELETE_ON_CLOSE       0x04000000
#define FILE_FLAG_BACKUP_SEMANTICS      0x02000000
#define FILE_FLAG_POSIX_SEMANTICS       0x01000000

#define FILE_TYPE_UNKNOWN   0x0000
#define FILE_TYPE_DISK      0x0001
#define FILE_TYPE_CHAR      0x0002
#define FILE_TYPE_PIPE      0x0003

#define FILE_ATTRIBUTE_DIRECTORY        0x0010
#define FILE_ATTRIBUTE_NORMAL           0x0080
#define FILE_ATTRIBUTE_READONLY		0x0001
#define FILE_SHARE_READ                 0x0001
#define FILE_SHARE_WRITE                0x0002

#define CREATE_NEW          1
#define CREATE_ALWAYS       2
#define OPEN_EXISTING       3
#define OPEN_ALWAYS         4
#define TRUNCATE_EXISTING   5





#undef MAX_PATH
#define MAX_PATH 260		/* ??? should be in windef.h */

typedef struct
  {
    DWORD dwFileAttributes;
    FILETIME ftCreationTime;
    FILETIME ftLastAccessTime;
    FILETIME ftLastWriteTime;
    DWORD nFileSizeHigh;
    DWORD nFileSizeLow;
    DWORD dwReserved0;
    DWORD dwReserved1;
    CHAR cFileName[MAX_PATH];
    CHAR cAlternateFileName[14];
  }
WIN32_FIND_DATAA;



typedef struct WIN32_FIND_DATA *LPWIN32_FIND_DATA;

BOOL WINAPI ContinueDebugEvent (DWORD pid, DWORD hid, int flags);
HANDLE WINAPI CreateFileA (const char *, DWORD, DWORD, void *, DWORD, DWORD, DWORD);
HANDLE WINAPI CreateFileW (const wchar_t *, DWORD, DWORD, void *, DWORD, DWORD, DWORD);
HANDLE WINAPI FindFirstFileA (const char *, WIN32_FIND_DATAA *);
BOOL WINAPI FindNextFileA (HANDLE, WIN32_FIND_DATAA *);
BOOL WINAPI GetCommState (HANDLE dev, DCB * p);
BOOL WINAPI GetCommTimeouts (HANDLE hdev, COMMTIMEOUTS * p);
DWORD WINAPI GetFileSize (HANDLE h, DWORD * size);
DWORD WINAPI GetFullPathNameA (const char *, DWORD, char *, char **);
DWORD WINAPI GetModuleFileNameA (HINSTANCE, char *, int);
unsigned int WINAPI GetPrivateProfileIntA (const char *, const char *, int, const char *);
unsigned int WINAPI GetPrivateProfileIntW (const wchar_t *, const wchar_t *, int, const wchar_t *);
DWORD WINAPI GetPrivateProfileSectionA (const char *, char *, DWORD, const char *);
DWORD WINAPI GetPrivateProfileSectionW (const wchar_t *, wchar_t *, DWORD, const wchar_t *);
DWORD WINAPI GetPrivateProfileStringA (const char *, const char *, const char *, char *, DWORD, const char *);
DWORD WINAPI GetPrivateProfileStringW (const wchar_t *, const wchar_t *, const wchar_t *, wchar_t *, DWORD, const wchar_t *);
DWORD WINAPI GetProfileSectionA (const char *, char *, DWORD);
DWORD WINAPI GetProfileSectionW (const wchar_t *, wchar_t *, DWORD);
HANDLE WINAPI GetStdHandle (int);
WINAPI void *GlobalAlloc (DWORD flags, DWORD size);
BOOL WINAPI GlobalFree (HGLOBAL);
WINAPI void *GlobalLock (HGLOBAL);
BOOL WINAPI GlobalUnlock (HGLOBAL);
long WINAPI _hread (HFILE h, void *ptr, unsigned len);
long WINAPI _hwrite (HFILE h, const char *ptr, unsigned len);
HFILE WINAPI _lclose (HFILE h);
HFILE WINAPI _lcreat (const char *path, int ats);
long WINAPI _llseek (HFILE h, long off, int dir);
HFILE WINAPI _lopen (const char *path, int fla);
long WINAPI _lread (HFILE h, void *ptr, unsigned len);
WINAPI char *lstrcatA (char *, const char *);
WINAPI wchar_t *lstrcatW (wchar_t *, const wchar_t *);
WINAPI int lstrcmpiA (const char *a, const char *b);
WINAPI int lstrcmpiW (const wchar_t * a, const wchar_t * b);
WINAPI char *lstrcpyA (char *, const char *);
WINAPI wchar_t *lstrcpyW (wchar_t *, const wchar_t *);
int WINAPI lstrlenA (const char *);
WINAPI int lstrlenW (const wchar_t *);
long WINAPI _lwrite (HFILE h, const char *ptr, unsigned len);
BOOL WINAPI RaiseException (DWORD, DWORD, DWORD, DWORD);
BOOL WINAPI ReadProcessMemory (HANDLE ph, DWORD addr, void *, int, DWORD *);
BOOL WINAPI SetCommState (HANDLE dev, DCB * p);
BOOL WINAPI SetCommTimeouts (HANDLE hdev, COMMTIMEOUTS * p);
VOID WINAPI Sleep (DWORD);
BOOL WINAPI WritePrivateProfileSectionA (const char *, const char *, const char *);
BOOL WINAPI WritePrivateProfileSectionW (const wchar_t *, const wchar_t *, const wchar_t *);
BOOL WINAPI WritePrivateProfileStringA (const char *, const char *, const char *, const char *);
BOOL WINAPI WriteProfileStringW (const wchar_t *, const wchar_t *, const wchar_t *, char *);
BOOL WINAPI WritePrivateProfileStringW (const wchar_t *, const wchar_t *, const wchar_t *, const wchar_t *);
BOOL WINAPI WriteProcessMemory (HANDLE ph, DWORD addr, void *, int, DWORD *);
BOOL WINAPI WriteProfileSectionA (const char *, const char *, char *);
BOOL WINAPI WriteProfileSectionW (const wchar_t *, const wchar_t *, char *);

WINAPI char * GetEnvironmentStrings (void);
DWORD WINAPI GetEnvironmentVariableA (char *, char *, DWORD);
BOOL WINAPI SetEnvironmentVariableA (char *, char *);
WINAPI char * GetCommandLineA (void);
void WINAPI ExitProcess (DWORD) __attribute__((__noreturn__));
BOOL WINAPI SetCurrentDirectoryA (const char *);
WINAPI void * LocalAlloc (DWORD flags, DWORD size);
WINAPI  void *LocalReAlloc (void *, DWORD size, DWORD flags);
WINAPI  void *LocalFree(void *);
BOOL WINAPI ReadFile (HANDLE, const void *, DWORD, DWORD *, OVERLAPPED *);
BOOL WINAPI WriteFile (HANDLE, const void *, DWORD, DWORD *, OVERLAPPED *);
DWORD WINAPI GetCurrentDirectoryA (DWORD , char *);
DWORD WINAPI CreateDirectoryA  (const char*, void *) ;
DWORD WINAPI RemoveDirectoryA (const char *);
DWORD WINAPI GetLastError (void);
DWORD WINAPI CloseHandle (HANDLE);
BOOL WINAPI DuplicateHandle(HANDLE, HANDLE, HANDLE, HANDLE *, DWORD, BOOL, DWORD);
DWORD WINAPI DeleteFileA (const char *);
BOOL WINAPI FindClose (HANDLE);
DWORD WINAPI GetFileInformationByHandle(HANDLE, BY_HANDLE_FILE_INFORMATION *);
DWORD WINAPI GetExitCodeProcess (HANDLE, DWORD *);
DWORD WINAPI CopyFileA (const char *, const char *, DWORD);
DWORD WINAPI WaitForSingleObject(HANDLE, DWORD );
DWORD WINAPI WaitForMultipleObjects (DWORD, HANDLE *, BOOL, DWORD);
WINAPI char * RtlUnwind(void *,void *,void *,void *);
WINAPI void * GetProcessHeap (void);
DWORD WINAPI GetProcessTimes(HANDLE, FILETIME *,FILETIME *,FILETIME *,FILETIME *);

HANDLE WINAPI CreateThread(SECURITY_ATTRIBUTES *,
			   DWORD, void (*func)(LPVOID), void *, DWORD, DWORD *);

BOOL WINAPI TerminateThread(HANDLE,  DWORD);
DWORD WINAPI GetExitCodeThread (HANDLE, DWORD *);


typedef struct 
{
  int stuff[8];
} CRITICAL_SECTION;

void WINAPI InitializeCriticalSection(CRITICAL_SECTION *);
void WINAPI EnterCriticalSection (CRITICAL_SECTION *);
void WINAPI LeaveCriticalSection(CRITICAL_SECTION *);
void WINAPI DeleteCriticalSection(CRITICAL_SECTION *);
BOOL WINAPI PulseEvent(HANDLE);
HANDLE WINAPI GetModuleHandleA(const char *);
BOOL WINAPI FreeEnvironmentStringsA(const char *);

HGLOBAL WINAPI GlobalReAlloc( HGLOBAL, int, unsigned);
