#ifdef __cplusplus
extern "C" {
#endif



  int cygwin_set_attributes(int what, int val);

#define CYGWIN_FMODE_ALL_BINARY 0

#ifdef __cplusplus
};
#endif
