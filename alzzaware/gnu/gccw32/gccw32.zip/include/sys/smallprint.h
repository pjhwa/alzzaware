#include <stdarg.h>

int __small_sprintf (char *dst, const char*fmt, ...);
int __small_vsprintf (char *dst, const char *fmt, va_list ap);
