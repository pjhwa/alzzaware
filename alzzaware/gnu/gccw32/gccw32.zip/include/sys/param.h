#ifndef _SYS_PARAM_H
# define _SYS_PARAM_H

#define PATH_MAX	1024
#define MAXPATHLEN 	1024
#define NOFILE 64
#define PATHSIZE 	(1024)
#define HZ 		100 /* not sure abou this */
#define MAXHOSTNAMELEN 64

#include <limits.h>
#endif
