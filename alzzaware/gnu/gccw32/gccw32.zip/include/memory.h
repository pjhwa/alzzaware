
/* This allows more things to compile. */
#include <string.h>
