#ifndef	_PATHS_H_
#define _PATHS_H_

#define _PATH_DEV	"/dev/"
#define _PATH_BSHELL    "/bin/sh"
#define _PATH_LASTLOG   "/var/log/lastlog"
#define _PATH_UTMP	"/var/run/utmp"
#define _PATH_WTMP	"/var/log/wtmp"
#endif /* _PATHS_H_ */
