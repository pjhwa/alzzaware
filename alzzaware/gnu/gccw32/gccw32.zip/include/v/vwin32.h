//===============================================================
// vwin32.h - Special defs for Win32 - Windows version
//
// Copyright (C) 1995,1996  Bruce E. Wampler
//
// This file is part of the V C++ GUI Framework, and is covered
// under the terms of the GNU Library General Public License,
// Version 2. This library has NO WARRANTY. See the source file
// vapp.cxx for more complete information about license terms.
//===============================================================

#ifndef VWIN32_H
#define VWIN32_H

#ifdef _WIN32
#define MoveTo(a,b,c) MoveToEx(a,b,c,0)
#define SetWindowExt(a,b,c) SetWindowExtEx(a,b,c,0)
#define SetViewportExt(a,b,c) SetViewportExtEx(a,b,c,0)
#endif
#endif